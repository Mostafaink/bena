-- ADMIN_AUTH_PROFILE_RECONCILE.sql
-- One-pass diagnosis + reconcile for admin auth/profile mismatch.
-- Run in Supabase SQL Editor.

begin;

-- 1) Show current auth users and profile rows for admin email
select 'AUTH_USERS' as section, id, email, created_at
from auth.users
where lower(email) = 'admin@cank.local'
order by created_at desc;

select 'PROFILES' as section, id, email, role, created_at
from public.profiles
where lower(email) = 'admin@cank.local'
order by created_at desc;

-- 2) Pick auth user and reconcile profiles/balances/offers
-- Priority: admin@cank.local, fallback: latest auth user.
do $$
declare
  admin_id uuid;
  admin_email text;
begin
  select id into admin_id
  from auth.users
  where lower(email) = 'admin@cank.local'
  order by created_at desc
  limit 1;

  if admin_id is null then
    select id, email
    into admin_id, admin_email
    from auth.users
    order by created_at desc
    limit 1;
  else
    admin_email := 'admin@cank.local';
  end if;

  if admin_id is null then
    raise exception 'No rows exist in auth.users. Create at least one user in Authentication -> Users first.';
  end if;

  -- Repoint stale rows from duplicate profile IDs to the real auth ID
  update public.offers
  set user_id = admin_id
  where user_id in (
    select id from public.profiles where lower(email) = 'admin@cank.local' and id <> admin_id
  );

  update public.balances
  set user_id = admin_id
  where user_id in (
    select id from public.profiles where lower(email) = 'admin@cank.local' and id <> admin_id
  );

  delete from public.profiles
  where lower(email) = 'admin@cank.local' and id <> admin_id;

  insert into public.profiles (id, email, role, first_name, full_name)
  values (admin_id, coalesce(admin_email, 'admin@cank.local'), 'admin', 'Admin', 'Admin User')
  on conflict (id) do update
  set email = excluded.email,
      role = 'admin',
      first_name = 'Admin',
      full_name = 'Admin User';

  insert into public.balances (user_id, cards_balance, collect_balance)
  values (admin_id, 10000, 5000)
  on conflict (user_id) do update
  set cards_balance = excluded.cards_balance,
      collect_balance = excluded.collect_balance;
end $$;

commit;

-- 3) Final verification snapshot
select 'AUTH_USERS_AFTER' as section, id, email, created_at
from auth.users
where lower(email) = 'admin@cank.local'
order by created_at desc;

select 'PROFILES_AFTER' as section, id, email, role, created_at
from public.profiles
where lower(email) = 'admin@cank.local'
order by created_at desc;

select 'BALANCES_AFTER' as section, user_id, cards_balance, collect_balance, created_at
from public.balances
where user_id in (select id from public.profiles where lower(email) = 'admin@cank.local')
order by created_at desc;
