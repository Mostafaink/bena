-- Safe demo bootstrap (data-only)
-- Purpose: create/update demo profile + balance rows without changing RLS policies.
-- Run this in Supabase SQL Editor as project owner.

BEGIN;

INSERT INTO public.profiles (
  id,
  email,
  first_name,
  full_name,
  role,
  created_at,
  updated_at
)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.local',
  'Demo',
  'Demo User',
  'admin',
  now(),
  now()
)
ON CONFLICT (id)
DO UPDATE SET
  email = EXCLUDED.email,
  first_name = EXCLUDED.first_name,
  full_name = EXCLUDED.full_name,
  role = EXCLUDED.role,
  updated_at = now();

INSERT INTO public.balances (
  user_id,
  cards_balance,
  collect_balance,
  created_at,
  updated_at
)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000,
  500,
  now(),
  now()
)
ON CONFLICT (user_id)
DO UPDATE SET
  cards_balance = EXCLUDED.cards_balance,
  collect_balance = EXCLUDED.collect_balance,
  updated_at = now();

COMMIT;

SELECT
  (SELECT count(*) FROM public.profiles WHERE id = '00000000-0000-0000-0000-000000000001') AS profile_exists,
  (SELECT count(*) FROM public.balances WHERE user_id = '00000000-0000-0000-0000-000000000001') AS balance_exists;
