-- ⭐ FINAL FIX FOR LOCALHOST DEMO MODE ⭐
-- Run this in Supabase SQL Editor to complete the setup
-- This adds the missing RLS policies for profiles and balances

-- ============================================
-- PROFILES TABLE - Allow demo access
-- ============================================
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "demo_profiles_read" ON profiles;
DROP POLICY IF EXISTS "demo_profiles_manage" ON profiles;
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;

-- Create permissive demo policies
CREATE POLICY "demo_profiles_read"
  ON profiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_profiles_insert"
  ON profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_profiles_update"
  ON profiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "demo_profiles_delete"
  ON profiles FOR DELETE
  TO anon, authenticated
  USING (true);

-- ============================================
-- BALANCES TABLE - Allow demo access
-- ============================================
ALTER TABLE balances ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Users can read own balance" ON balances;
DROP POLICY IF EXISTS "Users can update own balance" ON balances;
DROP POLICY IF EXISTS "demo_balances_read" ON balances;
DROP POLICY IF EXISTS "demo_balances_manage" ON balances;
DROP POLICY IF EXISTS "balances_select_own" ON balances;
DROP POLICY IF EXISTS "balances_update_own" ON balances;

-- Create permissive demo policies
CREATE POLICY "demo_balances_read"
  ON balances FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_balances_insert"
  ON balances FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_balances_update"
  ON balances FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "demo_balances_delete"
  ON balances FOR DELETE
  TO anon, authenticated
  USING (true);

-- ============================================
-- CREATE DEMO USER DATA
-- ============================================

-- Add phone columns if they don't exist (for future phone auth)
ALTER TABLE profiles 
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS phone_national text;

-- Make email nullable for phone-only users
DO $$ 
BEGIN
  ALTER TABLE profiles ALTER COLUMN email DROP NOT NULL;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Insert/update demo profile
INSERT INTO profiles (id, email, first_name, full_name, role, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.local',
  'Demo',
  'Demo User',
  'admin',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE
SET 
  role = 'admin',
  first_name = 'Demo',
  full_name = 'Demo User',
  email = 'demo@cank.local',
  updated_at = NOW();

-- Insert/update demo balance
INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000.00,
  500.00,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE
SET 
  cards_balance = 1000.00,
  collect_balance = 500.00,
  updated_at = NOW();

-- ============================================
-- VERIFICATION
-- ============================================
SELECT 
  '✅ SETUP COMPLETE!' as status,
  (SELECT COUNT(*) FROM profiles WHERE id = '00000000-0000-0000-0000-000000000001') as profile_exists,
  (SELECT role FROM profiles WHERE id = '00000000-0000-0000-0000-000000000001') as profile_role,
  (SELECT COUNT(*) FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000001') as balance_exists,
  (SELECT cards_balance FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000001') as cards_balance,
  (SELECT COUNT(*) FROM offers WHERE user_id = '00000000-0000-0000-0000-000000000001') as total_offers;
