-- RESTORE_ADMIN_PANEL.sql
-- This creates an admin account directly in the database
-- Run this in Supabase SQL Editor

begin;

-- Temporarily disable RLS to insert admin data
alter table public.profiles disable row level security;
alter table public.balances disable row level security;

-- Create admin profile (you can change the UUID if you have a specific auth user)
insert into public.profiles (id, email, first_name, full_name, role)
values (
  '00000000-0000-0000-0000-000000000001',
  'admin@cank.local',
  'Admin',
  'Admin User',
  'admin'
)
on conflict (id) do update
set role = 'admin', email = 'admin@cank.local';

-- Create admin balance
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '00000000-0000-0000-0000-000000000001',
  5000,
  2500
)
on conflict (user_id) do update
set cards_balance = 5000, collect_balance = 2500;

-- Re-enable RLS
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

-- Add permissive INSERT policies (allow signup)
drop policy if exists "signup_insert_profile" on public.profiles;
drop policy if exists "signup_insert_balance" on public.balances;

create policy "signup_insert_profile"
  on public.profiles
  for insert
  to public
  with check (true);

create policy "signup_insert_balance"
  on public.balances
  for insert
  to public
  with check (true);

commit;

-- RESULT: Admin account is now in database:
-- Email: admin@cank.local
-- User ID: 00000000-0000-0000-0000-000000000001
-- Role: admin
-- 
-- NEXT: Create a matching auth user OR switch app to demo mode to use this profile
