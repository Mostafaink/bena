-- FIX_PROFILE_BALANCE_RECURSION_ONLY.sql
-- Minimal safe patch: fix recursive RLS on profiles/balances only.
-- Run this once in Supabase SQL Editor.

begin;

-- Remove all existing policies on profiles/balances (some are recursive)
do $$
declare
  pol record;
begin
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'profiles'
  ) loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;

  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'balances'
  ) loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- Keep RLS enabled but NON-recursive
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

-- Profiles: user can read/insert/update own profile
create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- Balances: user can read/insert/update own balance
create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

commit;

-- Verify after run:
-- select id, email, role from public.profiles where id = auth.uid();
-- select user_id, cards_balance, collect_balance from public.balances where user_id = auth.uid();
