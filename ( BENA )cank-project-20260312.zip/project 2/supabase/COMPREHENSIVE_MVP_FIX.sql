-- COMPREHENSIVE SUPABASE FIX FOR MVP
-- Run this in SQL Editor to fix all backend issues

-- ==============================================
-- STEP 1: Fix RLS Policies (Enable Full Access)
-- ==============================================

-- Profiles: Allow full access
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- Balances: Allow full access  
ALTER TABLE balances DISABLE ROW LEVEL SECURITY;

-- Offers: Allow full access
ALTER TABLE offers DISABLE ROW LEVEL SECURITY;

-- Conversions: Allow full access
ALTER TABLE conversions DISABLE ROW LEVEL SECURITY;

-- User Flows: Allow full access (create if missing)
ALTER TABLE IF EXISTS user_flows DISABLE ROW LEVEL SECURITY;

-- ==============================================
-- STEP 2: Fix Offers Table Schema
-- ==============================================

-- Add missing columns to offers table
ALTER TABLE offers 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
ADD COLUMN IF NOT EXISTS template_id UUID,
ADD COLUMN IF NOT EXISTS is_template_instance BOOLEAN DEFAULT false;

-- Update existing records to have updated_at
UPDATE offers SET updated_at = created_at WHERE updated_at IS NULL;

-- ==============================================
-- STEP 3: Verify Core Data
-- ==============================================

-- Verify demo user profile
INSERT INTO profiles (id, email, first_name, full_name, role, created_at, updated_at)
VALUES ('00000000-0000-0000-0000-000000000001'::uuid, 'demo@cank.local', 'Demo', 'Demo User', 'admin', NOW(), NOW())
ON CONFLICT (id) DO NOTHING;

-- Verify demo user balance
INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES ('00000000-0000-0000-0000-000000000001'::uuid, 1000.00, 500.00, NOW(), NOW())
ON CONFLICT (user_id) DO NOTHING;

-- ==============================================
-- STEP 4: Create user_flows table if missing
-- ==============================================

CREATE TABLE IF NOT EXISTS user_flows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  flow_type VARCHAR(255),
  current_modal_step INT DEFAULT 0,
  last_action VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==============================================
-- STEP 5: Verify Everything Works
-- ==============================================

-- Check profiles
SELECT COUNT(*) as profile_count FROM profiles WHERE id = '00000000-0000-0000-0000-000000000001'::uuid;

-- Check balances
SELECT COUNT(*) as balance_count FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000001'::uuid;

-- Check offers
SELECT COUNT(*) as total_offers, 
       COUNT(CASE WHEN status = 'available' THEN 1 END) as available_offers,
       COUNT(CASE WHEN status = 'accepted' THEN 1 END) as accepted_offers
FROM offers;

-- Check conversions
SELECT COUNT(*) as analytics_count FROM conversions WHERE user_id = '00000000-0000-0000-0000-000000000001'::uuid;

-- Check user_flows
SELECT COUNT(*) as flows_count FROM user_flows WHERE user_id = '00000000-0000-0000-0000-000000000001'::uuid;

-- ==============================================
-- SUCCESS
-- ==============================================
-- If all counts are > 0, you're ready to move to the next phase!
