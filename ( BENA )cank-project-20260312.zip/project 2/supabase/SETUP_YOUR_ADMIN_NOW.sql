-- SETUP_YOUR_ADMIN_NOW.sql
-- Creates profile and balance for your admin user
-- User ID: 86baee96-139c-4399-896f-04c0e134fe7d

begin;

-- Create admin profile
insert into public.profiles (id, email, role, first_name, full_name)
values (
  '86baee96-139c-4399-896f-04c0e134fe7d'::uuid,
  'admin@cank.local',
  'admin',
  'Admin',
  'Admin User'
)
on conflict (id) do update
set role = 'admin', email = 'admin@cank.local', first_name = 'Admin', full_name = 'Admin User';

-- Create admin balance  
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '86baee96-139c-4399-896f-04c0e134fe7d'::uuid,
  10000,
  5000
)
on conflict (user_id) do update
set cards_balance = 10000, collect_balance = 5000;

commit;

-- Verify it worked
select 'Profile created:' as status, id, email, role from public.profiles where id = '86baee96-139c-4399-896f-04c0e134fe7d';
select 'Balance created:' as status, user_id, cards_balance, collect_balance from public.balances where user_id = '86baee96-139c-4399-896f-04c0e134fe7d';
