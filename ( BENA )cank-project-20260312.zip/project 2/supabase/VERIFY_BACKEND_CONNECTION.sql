-- Run this in Supabase SQL Editor to verify live backend data

SELECT current_database() AS db_name, current_schema() AS schema_name;

SELECT COUNT(*) AS total_offers FROM public.offers;

SELECT id, user_id, type, status, amount, created_at
FROM public.offers
ORDER BY created_at DESC
LIMIT 20;

SELECT id, email, role, created_at
FROM public.profiles
ORDER BY created_at DESC
LIMIT 10;

SELECT user_id, cards_balance, collect_balance, updated_at
FROM public.balances
ORDER BY updated_at DESC
LIMIT 10;
