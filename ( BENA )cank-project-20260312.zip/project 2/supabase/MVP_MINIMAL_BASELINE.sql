-- MVP_MINIMAL_BASELINE.sql
-- Canonical minimal backend for this app:
-- - offers (per-user)
-- - conversions (analytics events)
-- - user_flows (optional UX state)
-- - profiles (role/admin + basic user info)
--
-- This baseline intentionally excludes balances and aggregated analytics tables.

begin;

create extension if not exists pgcrypto;

-- =============================
-- Hard cleanup of legacy app tables (optional but safe)
-- Keeps only the minimal MVP model.
-- =============================
drop table if exists public.balances cascade;
drop table if exists public.offer_templates cascade;
drop table if exists public.offer_assignments cascade;
drop table if exists public.offer_analytics cascade;
drop table if exists public.offer_combinations cascade;
drop table if exists public.user_offers cascade;
drop table if exists public.page_visits cascade;
drop table if exists public.user_actions cascade;
drop table if exists public.user_conversions cascade;
drop table if exists public.flows cascade;
drop table if exists public.admin_users cascade;

-- =============================
-- profiles
-- =============================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  role text not null default 'user' check (role in ('user','admin')),
  first_name text,
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- =============================
-- offers
-- =============================
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null check (type in ('cash', 'receivables')),
  status text not null default 'available' check (status in ('available', 'accepted')),
  amount numeric(12,2) not null check (amount >= 0),
  config jsonb not null default '{}'::jsonb,
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_offers_user_id on public.offers(user_id);
create index if not exists idx_offers_status on public.offers(status);
create index if not exists idx_offers_type on public.offers(type);

-- =============================
-- conversions (raw analytics events)
-- =============================
create table if not exists public.conversions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_conversions_user_id on public.conversions(user_id);
create index if not exists idx_conversions_action on public.conversions(action);
create index if not exists idx_conversions_created_at on public.conversions(created_at);

-- =============================
-- user_flows
-- =============================
create table if not exists public.user_flows (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  flow_type text not null default 'standard',
  current_modal_step int not null default 0,
  last_action text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_user_flows_user_id on public.user_flows(user_id);

-- =============================
-- Updated-at trigger helper
-- =============================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists trg_offers_updated_at on public.offers;
create trigger trg_offers_updated_at
before update on public.offers
for each row execute function public.set_updated_at();

drop trigger if exists trg_user_flows_updated_at on public.user_flows;
create trigger trg_user_flows_updated_at
before update on public.user_flows
for each row execute function public.set_updated_at();

-- =============================
-- RLS
-- =============================
alter table public.profiles enable row level security;
alter table public.offers enable row level security;
alter table public.conversions enable row level security;
alter table public.user_flows enable row level security;

-- profiles policies
drop policy if exists profiles_select_own on public.profiles;
drop policy if exists profiles_insert_own on public.profiles;
drop policy if exists profiles_update_own on public.profiles;

create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- offers policies
drop policy if exists offers_select_own on public.offers;
drop policy if exists offers_insert_own on public.offers;
drop policy if exists offers_update_own on public.offers;
drop policy if exists offers_delete_own on public.offers;
drop policy if exists offers_select_admin_all on public.offers;
drop policy if exists offers_update_admin_all on public.offers;
drop policy if exists offers_delete_admin_all on public.offers;
drop policy if exists offers_insert_admin_any on public.offers;

create policy offers_select_own
  on public.offers
  for select
  to authenticated
  using (user_id = auth.uid());

create policy offers_insert_own
  on public.offers
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy offers_update_own
  on public.offers
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy offers_delete_own
  on public.offers
  for delete
  to authenticated
  using (user_id = auth.uid());

-- admin can manage offers for all users
create policy offers_select_admin_all
  on public.offers
  for select
  to authenticated
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

create policy offers_update_admin_all
  on public.offers
  for update
  to authenticated
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  )
  with check (true);

create policy offers_delete_admin_all
  on public.offers
  for delete
  to authenticated
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

create policy offers_insert_admin_any
  on public.offers
  for insert
  to authenticated
  with check (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- conversions policies
drop policy if exists conversions_insert_own on public.conversions;
drop policy if exists conversions_select_own_or_admin on public.conversions;

create policy conversions_insert_own
  on public.conversions
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy conversions_select_own_or_admin
  on public.conversions
  for select
  to authenticated
  using (
    user_id = auth.uid()
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- user_flows policies
drop policy if exists user_flows_select_own on public.user_flows;
drop policy if exists user_flows_insert_own on public.user_flows;
drop policy if exists user_flows_update_own on public.user_flows;

create policy user_flows_select_own
  on public.user_flows
  for select
  to authenticated
  using (user_id = auth.uid());

create policy user_flows_insert_own
  on public.user_flows
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy user_flows_update_own
  on public.user_flows
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- RPC used by frontend admin check
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  );
$$;

grant execute on function public.is_admin() to authenticated;

commit;
