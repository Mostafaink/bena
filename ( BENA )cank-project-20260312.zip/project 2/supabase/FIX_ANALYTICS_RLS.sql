-- FIX_ANALYTICS_RLS.sql
-- Ensure conversions analytics writes/reads work for authenticated users.

begin;

-- Conversions table policies
alter table if exists public.conversions enable row level security;

drop policy if exists conversions_insert_own on public.conversions;
drop policy if exists conversions_select_own_or_admin on public.conversions;
drop policy if exists "Users can insert conversions" on public.conversions;
drop policy if exists "Users can view own conversions" on public.conversions;
drop policy if exists "Admins can view all conversions" on public.conversions;

create policy conversions_insert_own
  on public.conversions
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy conversions_select_own_or_admin
  on public.conversions
  for select
  to authenticated
  using (
    user_id = auth.uid()
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- Allow analytics refresh RPC for authenticated users
-- (The function should be SECURITY DEFINER in migrations; this grant is safe/idempotent.)
grant execute on function public.refresh_offer_analytics() to authenticated;

commit;

-- Verification
select tablename, policyname, cmd
from pg_policies
where schemaname = 'public' and tablename = 'conversions'
order by policyname;
