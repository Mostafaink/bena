-- FIX_BALANCE_RECURSION_AND_OFFERS_RLS.sql
-- Fixes remaining recursive policy + adds missing offers RLS policies

begin;

-- 1. Check what's causing the balance/profiles recursion
select 
  schemaname,
  tablename, 
  policyname,
  qual,
  with_check
from pg_policies 
where schemaname = 'public' 
  and tablename in ('profiles', 'balances')
order by tablename, policyname;

-- 2. Drop and recreate balances policies (non-recursive)
drop policy if exists balances_select_own on public.balances;
drop policy if exists balances_insert_own on public.balances;
drop policy if exists balances_update_own on public.balances;

create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances  
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 3. Add offers table RLS policies (currently missing!)
alter table public.offers enable row level security;

drop policy if exists offers_select_own on public.offers;
drop policy if exists offers_insert_own on public.offers;
drop policy if exists offers_update_own on public.offers;
drop policy if exists offers_delete_own on public.offers;

create policy offers_select_own
  on public.offers
  for select
  to authenticated
  using (user_id = auth.uid());

create policy offers_insert_own
  on public.offers
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy offers_update_own
  on public.offers
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy offers_delete_own
  on public.offers
  for delete
  to authenticated
  using (user_id = auth.uid());

commit;

-- Verification
select 'Balances policies' as section, policyname from pg_policies where tablename = 'balances';
select 'Offers policies' as section, policyname from pg_policies where tablename = 'offers';
