-- VERIFY_ALL_OFFERS.sql
-- Shows ALL offers (accepted and available) for admin verification

select 
  'OFFER SUMMARY' as info,
  status,
  type,
  count(*) as count,
  sum(amount) as total_amount
from public.offers
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
group by status, type
order by status, type;

select 
  'DETAILED VIEW' as info,
  id,
  type,
  amount,
  status,
  created_at,
  accepted_at
from public.offers
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
order by created_at desc
limit 20;

select 
  'TOTAL COUNT' as info,
  count(*) as all_offers,
  count(*) filter (where status = 'available') as available_offers,
  count(*) filter (where status = 'accepted') as accepted_offers
from public.offers
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
