-- ============================================
-- FIX RLS POLICIES FOR DEMO MODE
-- ============================================
-- Allow demo user to create/modify offers without authentication
-- This is for development/demo only
-- ============================================

-- Drop existing policies on offers table
DROP POLICY IF EXISTS "Users can read own offers" ON offers;
DROP POLICY IF EXISTS "Admins can read all offers" ON offers;
DROP POLICY IF EXISTS "Users can insert own offers" ON offers;
DROP POLICY IF EXISTS "Users can update own offers" ON offers;
DROP POLICY IF EXISTS "Users can delete own offers" ON offers;
DROP POLICY IF EXISTS "Admins can manage all offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to read offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to insert offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to update offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to delete offers" ON offers;

-- Create new permissive policies for demo
CREATE POLICY "Allow demo user to read offers"
  ON offers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow demo user to insert offers"
  ON offers FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow demo user to update offers"
  ON offers FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow demo user to delete offers"
  ON offers FOR DELETE
  TO anon, authenticated
  USING (true);

-- Also fix offer_templates policies
DROP POLICY IF EXISTS "Anyone can read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Admins can manage all templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow manage templates demo" ON offer_templates;

CREATE POLICY "Allow read active templates"
  ON offer_templates FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Allow manage templates demo"
  ON offer_templates FOR ALL
  TO anon, authenticated
  WITH CHECK (true);

-- Fix offer_assignments policies
DROP POLICY IF EXISTS "Users can read own assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Admins can manage all assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow manage assignments demo" ON offer_assignments;

CREATE POLICY "Allow read assignments"
  ON offer_assignments FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow manage assignments demo"
  ON offer_assignments FOR ALL
  TO anon, authenticated
  WITH CHECK (true);

-- ============================================
-- SUCCESS!
-- ============================================
-- Now the demo app can read/write to database
-- without authentication
-- ============================================
