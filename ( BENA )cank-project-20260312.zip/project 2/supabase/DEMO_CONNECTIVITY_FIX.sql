-- Demo connectivity fix: make current frontend UUID flow work with Supabase immediately
-- Run in Supabase SQL Editor as one query

-- 1) Allow demo UUID writes by removing auth.users FK dependency on offers.user_id
ALTER TABLE IF EXISTS offers
  DROP CONSTRAINT IF EXISTS offers_user_id_fkey;

-- 2) Ensure RLS does not block anon key usage for demo
ALTER TABLE IF EXISTS offers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own offers" ON offers;
DROP POLICY IF EXISTS "Users can insert own offers" ON offers;
DROP POLICY IF EXISTS "Users can update own offers" ON offers;
DROP POLICY IF EXISTS "Users can delete own offers" ON offers;
DROP POLICY IF EXISTS "Admins can read all offers" ON offers;
DROP POLICY IF EXISTS "Admins can manage all offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to read offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to insert offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to update offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to delete offers" ON offers;

CREATE POLICY "Demo read offers"
  ON offers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Demo insert offers"
  ON offers FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Demo update offers"
  ON offers FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Demo delete offers"
  ON offers FOR DELETE
  TO anon, authenticated
  USING (true);

-- 3) Ensure templates and assignments are usable in demo mode
ALTER TABLE IF EXISTS offer_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Admins can manage all templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow manage templates demo" ON offer_templates;

CREATE POLICY "Demo read templates"
  ON offer_templates FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Demo manage templates"
  ON offer_templates FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

ALTER TABLE IF EXISTS offer_assignments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Admins can manage all assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow manage assignments demo" ON offer_assignments;

CREATE POLICY "Demo read assignments"
  ON offer_assignments FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Demo manage assignments"
  ON offer_assignments FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- 4) user_flows is used by frontend; create if missing
CREATE TABLE IF NOT EXISTS user_flows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL UNIQUE,
  flow_type text NOT NULL DEFAULT 'standard',
  current_modal_step integer DEFAULT 0,
  last_action text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_flows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can insert user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can update user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can delete user flows" ON user_flows;

CREATE POLICY "Demo read flows"
  ON user_flows FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Demo insert flows"
  ON user_flows FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Demo update flows"
  ON user_flows FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Demo delete flows"
  ON user_flows FOR DELETE
  TO anon, authenticated
  USING (true);

-- 5) Ensure demo profile exists
INSERT INTO profiles (id, email, first_name, full_name, role, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.com',
  'Demo',
  'Demo Admin',
  'admin',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE
SET role = 'admin', first_name = 'Demo', full_name = 'Demo Admin', updated_at = NOW();

INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000,
  500,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE
SET cards_balance = EXCLUDED.cards_balance,
    collect_balance = EXCLUDED.collect_balance,
    updated_at = NOW();

-- Quick verification
SELECT 'offers_fk_present' AS check_name,
       EXISTS (
         SELECT 1 FROM information_schema.table_constraints
         WHERE table_name='offers' AND constraint_type='FOREIGN KEY' AND constraint_name='offers_user_id_fkey'
       )::text AS value
UNION ALL
SELECT 'offers_rows', (SELECT COUNT(*) FROM offers)::text;
