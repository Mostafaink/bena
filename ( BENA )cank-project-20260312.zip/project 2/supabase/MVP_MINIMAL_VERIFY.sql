-- MVP_MINIMAL_VERIFY.sql
-- Verify canonical minimal backend state.

-- table existence
select table_name
from information_schema.tables
where table_schema = 'public'
  and table_name in ('profiles', 'offers', 'conversions', 'user_flows')
order by table_name;

-- policies
select tablename, policyname, cmd
from pg_policies
where schemaname = 'public'
  and tablename in ('profiles', 'offers', 'conversions', 'user_flows')
order by tablename, policyname;

-- row counts
select 'profiles' as table_name, count(*)::bigint as row_count from public.profiles
union all
select 'offers', count(*)::bigint from public.offers
union all
select 'conversions', count(*)::bigint from public.conversions
union all
select 'user_flows', count(*)::bigint from public.user_flows;

-- event distribution
select action, count(*)::bigint as count
from public.conversions
group by action
order by count desc, action asc;

-- admin check function
select public.is_admin() as am_i_admin;
