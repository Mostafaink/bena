/*
  # Phone-First Auth Hardening for MVP Scale

  Goals:
  - Support Egyptian phone OTP users (no required email)
  - Keep profile + balances auto-creation on auth signup
  - Preserve role-based authorization
*/

-- 1) Make profiles compatible with phone-only auth users
ALTER TABLE profiles
  ALTER COLUMN email DROP NOT NULL;

-- Add phone columns (E.164 + national display) if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'phone'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'phone_national'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone_national text;
  END IF;
END $$;

-- Unique phone for identity matching (nullable-safe unique)
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_phone_unique ON profiles(phone) WHERE phone IS NOT NULL;

-- 2) Replace signup trigger with phone-aware logic
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    first_name,
    full_name,
    phone,
    phone_national,
    role
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.phone,
      NEW.email,
      'User'
    ),
    NEW.phone,
    COALESCE(NEW.raw_user_meta_data->>'phone_national', NEW.phone),
    'user'
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.balances (user_id, cards_balance, collect_balance)
  VALUES (NEW.id, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
EXCEPTION
  WHEN others THEN
    RAISE LOG 'Error in handle_new_user: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- 3) Backfill profiles for existing auth users without profiles
INSERT INTO profiles (
  id,
  email,
  first_name,
  full_name,
  phone,
  phone_national,
  role
)
SELECT
  u.id,
  u.email,
  COALESCE(u.raw_user_meta_data->>'first_name', ''),
  COALESCE(u.raw_user_meta_data->>'full_name', u.phone, u.email, 'User'),
  u.phone,
  COALESCE(u.raw_user_meta_data->>'phone_national', u.phone),
  'user'
FROM auth.users u
LEFT JOIN profiles p ON p.id = u.id
WHERE p.id IS NULL;

INSERT INTO balances (user_id, cards_balance, collect_balance)
SELECT u.id, 0, 0
FROM auth.users u
LEFT JOIN balances b ON b.user_id = u.id
WHERE b.user_id IS NULL;

-- 4) Sanity checks
SELECT 'phone_auth_profiles_hardening_applied' AS status;
