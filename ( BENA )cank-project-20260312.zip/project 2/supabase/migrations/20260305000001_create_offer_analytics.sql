/*
  # Create Offer Analytics Table (Admin-Only)
  
  Aggregates offer performance data from conversions table.
  - Only admins can access this data
  - Users have no access to analytics
  - Populated by backend functions from conversions tracking
*/

-- Create offer_analytics table
CREATE TABLE IF NOT EXISTS offer_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id uuid NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  
  -- Aggregated metrics from conversions tracking
  views_count int DEFAULT 0,
  clicks_count int DEFAULT 0,
  accepted boolean DEFAULT false,
  accepted_at timestamptz,
  
  -- Timestamps
  first_tracked_at timestamptz DEFAULT now(),
  last_tracked_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(offer_id, user_id)
);

-- Create indexes for admin queries
CREATE INDEX IF NOT EXISTS idx_offer_analytics_offer_id ON offer_analytics(offer_id);
CREATE INDEX IF NOT EXISTS idx_offer_analytics_user_id ON offer_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_offer_analytics_accepted ON offer_analytics(accepted);

-- Enable RLS
ALTER TABLE offer_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policy: ONLY ADMINS can read all analytics
CREATE POLICY "Admins only - read all analytics"
  ON offer_analytics
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Block all other user access
CREATE POLICY "Block non-admin user access"
  ON offer_analytics
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Function to calculate/update analytics from conversions table
CREATE OR REPLACE FUNCTION refresh_offer_analytics()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert or update analytics based on conversions data
  INSERT INTO offer_analytics (
    offer_id,
    user_id,
    views_count,
    clicks_count,
    accepted,
    accepted_at,
    first_tracked_at,
    last_tracked_at,
    updated_at
  )
  SELECT 
    o.id as offer_id,
    o.user_id,
    COALESCE(
      (SELECT COUNT(*) FROM conversions 
       WHERE conversions.user_id = o.user_id 
       AND conversions.metadata->>'offer_id' = o.id::text
       AND conversions.action LIKE '%view%'
      ), 0
    ) as views_count,
    COALESCE(
      (SELECT COUNT(*) FROM conversions 
       WHERE conversions.user_id = o.user_id 
       AND conversions.metadata->>'offer_id' = o.id::text
       AND conversions.action LIKE '%click%'
      ), 0
    ) as clicks_count,
    (o.status = 'accepted') as accepted,
    o.accepted_at,
    COALESCE(
      (SELECT MIN(created_at) FROM conversions 
       WHERE conversions.user_id = o.user_id
       AND conversions.metadata->>'offer_id' = o.id::text
      ), now()
    ) as first_tracked_at,
    COALESCE(
      (SELECT MAX(created_at) FROM conversions 
       WHERE conversions.user_id = o.user_id
       AND conversions.metadata->>'offer_id' = o.id::text
      ), now()
    ) as last_tracked_at,
    now() as updated_at
  FROM offers o
  ON CONFLICT (offer_id, user_id) 
  DO UPDATE SET
    views_count = EXCLUDED.views_count,
    clicks_count = EXCLUDED.clicks_count,
    accepted = EXCLUDED.accepted,
    accepted_at = EXCLUDED.accepted_at,
    last_tracked_at = EXCLUDED.last_tracked_at,
    updated_at = now();
END;
$$;

-- Grant execute permission to authenticated users (function checks admin role internally if needed)
GRANT EXECUTE ON FUNCTION refresh_offer_analytics() TO authenticated;

COMMENT ON TABLE offer_analytics IS 'Admin-only analytics aggregated from user conversions and offers';
COMMENT ON FUNCTION refresh_offer_analytics() IS 'Calculates and updates offer analytics from conversions table';
