-- SETUP_ADMIN_PROFILE.sql  
-- After creating admin@cank.local in Authentication → Users,
-- replace YOUR_USER_ID_HERE with the actual UUID from the dashboard

begin;

-- Set up admin profile
insert into public.profiles (id, email, role, first_name, full_name)
values (
  'YOUR_USER_ID_HERE'::uuid,  -- REPLACE THIS with actual UUID!
  'admin@cank.local',
  'admin',
  'Admin',
  'Admin User'
)
on conflict (id) do update
set role = 'admin', email = 'admin@cank.local';

-- Set up admin balance
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  'YOUR_USER_ID_HERE'::uuid,  -- REPLACE THIS with actual UUID!
  10000,
  5000
)
on conflict (user_id) do nothing;

commit;

-- Verify
select 'Profile:', id, email, role from public.profiles where email = 'admin@cank.local'
union all
select 'Balance:', user_id, cards_balance::text, collect_balance::text from public.balances where user_id in (select id from public.profiles where email = 'admin@cank.local');
