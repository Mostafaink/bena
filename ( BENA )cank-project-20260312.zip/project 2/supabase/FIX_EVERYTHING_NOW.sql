-- FIX_EVERYTHING_NOW.sql
-- Fixes RLS recursion AND sets up correct admin user
-- Run this ONCE after deleting the duplicate user

begin;

-- 1. FIX RECURSIVE RLS (this is critical!)
do $$
declare
  pol record;
begin
  -- Drop ALL policies on profiles
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'profiles'
  ) loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;

  -- Drop ALL policies on balances
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'balances'
  ) loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- Enable RLS (but with NON-recursive policies)
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

-- Simple, non-recursive policies for profiles
create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- Simple, non-recursive policies for balances
create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 2 + 3. SET UP ADMIN PROFILE/BALANCE (using current auth.users ID)
do $$
declare
  admin_id uuid;
begin
  select id
  into admin_id
  from auth.users
  where email = 'admin@cank.local'
  order by created_at desc
  limit 1;

  if admin_id is null then
    raise exception 'admin@cank.local not found in auth.users';
  end if;

  -- Move any stale profile data (same email, wrong ID) to the real auth user ID.
  update public.offers
  set user_id = admin_id
  where user_id in (
    select id
    from public.profiles
    where email = 'admin@cank.local'
      and id <> admin_id
  );

  update public.balances
  set user_id = admin_id
  where user_id in (
    select id
    from public.profiles
    where email = 'admin@cank.local'
      and id <> admin_id
  );

  delete from public.profiles
  where email = 'admin@cank.local'
    and id <> admin_id;

  insert into public.profiles (id, email, role, first_name, full_name)
  values (
    admin_id,
    'admin@cank.local',
    'admin',
    'Admin',
    'Admin User'
  )
  on conflict (id) do update
  set role = 'admin', email = 'admin@cank.local', first_name = 'Admin', full_name = 'Admin User';

  insert into public.balances (user_id, cards_balance, collect_balance)
  values (
    admin_id,
    10000,
    5000
  )
  on conflict (user_id) do update
  set cards_balance = 10000, collect_balance = 5000;
end $$;

commit;

-- Verify everything worked
select '=== VERIFICATION ===' as status;
select 'Profile:' as type, id, email, role from public.profiles where email = 'admin@cank.local';
select 'Balance:' as type, user_id::text as id, cards_balance, collect_balance from public.balances where user_id in (select id from public.profiles where email = 'admin@cank.local');
select 'Offers:' as type, count(*)::text as count, '-' as role from public.offers where user_id in (select id from public.profiles where email = 'admin@cank.local');
