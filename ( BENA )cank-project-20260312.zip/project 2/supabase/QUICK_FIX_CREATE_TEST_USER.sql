-- FIXED: Create test user with proper UUID format
-- Copy and paste ALL of this into Supabase SQL Editor and click RUN

-- Step 1: Create test user profile (using valid UUID)
INSERT INTO profiles (
  id,
  email, 
  first_name,
  full_name,
  role,
  phone,
  phone_national,
  created_at,
  updated_at
) VALUES (
  '00000000-0000-0000-0000-000000000099'::uuid,
  'demo@cank.local',
  'Demo',
  'Demo Test User',
  'admin',
  '+201000000000',
  '01000000000',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE SET updated_at = NOW();

-- Step 2: Create balance for test user
INSERT INTO balances (
  user_id,
  cards_balance,
  collect_balance,
  created_at,
  updated_at
) VALUES (
  '00000000-0000-0000-0000-000000000099'::uuid,
  1000.00,
  500.00,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE SET 
  cards_balance = 1000.00,
  collect_balance = 500.00,
  updated_at = NOW();

-- Step 3: Verify everything was created
SELECT '✅ PROFILE' as check_item, COUNT(*) as count FROM profiles WHERE id = '00000000-0000-0000-0000-000000000099'::uuid
UNION ALL
SELECT '✅ BALANCE', COUNT(*) FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000099'::uuid
UNION ALL
SELECT '📊 OFFERS', COUNT(*) FROM offers WHERE user_id = '00000000-0000-0000-0000-000000000099'::uuid
UNION ALL
SELECT '📈 TOTAL OFFERS', COUNT(*) FROM offers;
