-- DIAGNOSE_POLICIES.sql
-- Show all current policies to identify recursion source

-- Show all RLS policies on key tables
select 
  'CURRENT POLICIES' as info,
  schemaname,
  tablename,
  policyname,
  cmd,
  substring(qual::text, 1, 100) as using_clause,
  substring(with_check::text, 1, 100) as  with_check_clause
from pg_policies
where schemaname = 'public'
  and tablename in ('profiles', 'balances', 'offers')
order by tablename, policyname;

-- Check foreign keys that might trigger cross-table checks
select
  'FOREIGN KEYS' as info,
  tc.table_name,
  kcu.column_name,
  ccu.table_name as foreign_table_name,
  ccu.column_name as foreign_column_name
from information_schema.table_constraints as tc
join information_schema.key_column_usage as kcu
  on tc.constraint_name = kcu.constraint_name
  and tc.table_schema = kcu.table_schema
join information_schema.constraint_column_usage as ccu
  on ccu.constraint_name = tc.constraint_name
  and ccu.table_schema = tc.table_schema
where tc.constraint_type = 'FOREIGN KEY'
  and tc.table_schema = 'public'
  and tc.table_name in ('profiles', 'balances', 'offers')
order by tc.table_name;
