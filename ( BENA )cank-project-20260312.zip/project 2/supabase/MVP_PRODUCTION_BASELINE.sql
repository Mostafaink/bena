-- MVP production baseline: secure, simple, scalable auth + authorization
-- Run in Supabase SQL editor after prior demo scripts.

-- 1) Ensure profiles reference auth.users for real auth-based identity
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.table_constraints
    WHERE table_name = 'profiles'
      AND constraint_name = 'profiles_id_fkey'
      AND constraint_type = 'FOREIGN KEY'
  ) THEN
    -- already good
    NULL;
  ELSE
    ALTER TABLE profiles
      ADD CONSTRAINT profiles_id_fkey
      FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- 2) Keep offers.user_id as uuid; do NOT force FK to auth.users to preserve compatibility with existing data.
-- Security is enforced by RLS with auth.uid().

-- 3) Helper function for admin checks
CREATE OR REPLACE FUNCTION public.is_admin(uid uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = uid AND p.role = 'admin'
  );
$$;

-- 4) Harden offers policies
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own offers" ON offers;
DROP POLICY IF EXISTS "Users can insert own offers" ON offers;
DROP POLICY IF EXISTS "Users can update own offers" ON offers;
DROP POLICY IF EXISTS "Users can delete own offers" ON offers;
DROP POLICY IF EXISTS "Admins can read all offers" ON offers;
DROP POLICY IF EXISTS "Admins can manage all offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to read offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to insert offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to update offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to delete offers" ON offers;
DROP POLICY IF EXISTS "Demo read offers" ON offers;
DROP POLICY IF EXISTS "Demo insert offers" ON offers;
DROP POLICY IF EXISTS "Demo update offers" ON offers;
DROP POLICY IF EXISTS "Demo delete offers" ON offers;

CREATE POLICY "offers_select_own_or_admin"
  ON offers FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "offers_insert_own_or_admin"
  ON offers FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "offers_update_own_or_admin"
  ON offers FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()))
  WITH CHECK (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "offers_delete_admin_only"
  ON offers FOR DELETE
  TO authenticated
  USING (public.is_admin(auth.uid()));

-- 5) Harden template policies
ALTER TABLE offer_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Admins can manage all templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow manage templates demo" ON offer_templates;
DROP POLICY IF EXISTS "Demo read templates" ON offer_templates;
DROP POLICY IF EXISTS "Demo manage templates" ON offer_templates;

CREATE POLICY "templates_select_authenticated"
  ON offer_templates FOR SELECT
  TO authenticated
  USING (is_active = true OR public.is_admin(auth.uid()));

CREATE POLICY "templates_manage_admin_only"
  ON offer_templates FOR ALL
  TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

-- 6) Harden assignment policies
ALTER TABLE offer_assignments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Admins can manage all assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow manage assignments demo" ON offer_assignments;
DROP POLICY IF EXISTS "Demo read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Demo manage assignments" ON offer_assignments;

CREATE POLICY "assignments_select_own_or_admin"
  ON offer_assignments FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "assignments_manage_admin_only"
  ON offer_assignments FOR ALL
  TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

-- 7) Harden user_flows policies
ALTER TABLE user_flows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can insert user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can update user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can delete user flows" ON user_flows;
DROP POLICY IF EXISTS "Demo read flows" ON user_flows;
DROP POLICY IF EXISTS "Demo insert flows" ON user_flows;
DROP POLICY IF EXISTS "Demo update flows" ON user_flows;
DROP POLICY IF EXISTS "Demo delete flows" ON user_flows;

CREATE POLICY "flows_select_own_or_admin"
  ON user_flows FOR SELECT
  TO authenticated
  USING (user_id = auth.uid()::text OR public.is_admin(auth.uid()));

CREATE POLICY "flows_insert_own_or_admin"
  ON user_flows FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid()::text OR public.is_admin(auth.uid()));

CREATE POLICY "flows_update_own_or_admin"
  ON user_flows FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid()::text OR public.is_admin(auth.uid()))
  WITH CHECK (user_id = auth.uid()::text OR public.is_admin(auth.uid()));

CREATE POLICY "flows_delete_admin_only"
  ON user_flows FOR DELETE
  TO authenticated
  USING (public.is_admin(auth.uid()));

-- 8) Harden conversions policies (append-only from authenticated users)
ALTER TABLE conversions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can insert conversions" ON conversions;
DROP POLICY IF EXISTS "Users can view own conversions" ON conversions;
DROP POLICY IF EXISTS "Admins can view all conversions" ON conversions;

CREATE POLICY "conversions_insert_own"
  ON conversions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid()::text);

CREATE POLICY "conversions_select_own_or_admin"
  ON conversions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid()::text OR public.is_admin(auth.uid()));

-- 9) Harden analytics policies (admin only)
ALTER TABLE offer_analytics ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins only - read all analytics" ON offer_analytics;
DROP POLICY IF EXISTS "Block non-admin user access" ON offer_analytics;

CREATE POLICY "analytics_admin_only"
  ON offer_analytics FOR ALL
  TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

-- 10) Minimal indexes for scale
CREATE INDEX IF NOT EXISTS idx_offers_user_status ON offers(user_id, status);
CREATE INDEX IF NOT EXISTS idx_conversions_user_created ON conversions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignments_user_status ON offer_assignments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_flows_user ON user_flows(user_id);

-- Verification quick checks
SELECT 'baseline_applied' AS status;
