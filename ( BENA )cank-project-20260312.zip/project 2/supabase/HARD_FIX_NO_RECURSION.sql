-- HARD_FIX_NO_RECURSION.sql
-- Run this once in Supabase SQL Editor.
-- Fixes: "infinite recursion detected in policy for relation profiles"
-- Keeps admin panel backend-controlled by profiles.role.

begin;

-- 1) Rebuild trigger as conflict-safe and non-blocking
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Move conflicting legacy email aside if needed
  update public.profiles
  set email = 'legacy+' || id::text || '@cank.local'
  where email = new.email
    and id <> new.id;

  insert into public.profiles (id, email, first_name, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'first_name', split_part(coalesce(new.email, ''), '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    'user'
  )
  on conflict (id) do update
  set email = excluded.email,
      first_name = excluded.first_name,
      full_name = excluded.full_name;

  insert into public.balances (user_id, cards_balance, collect_balance)
  values (new.id, 0, 0)
  on conflict (user_id) do nothing;

  return new;
exception
  when others then
    raise log 'handle_new_user failed: %', sqlerrm;
    return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- 2) Drop all existing profiles/balances policies (including recursive ones)
do $$
declare
  pol record;
begin
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'profiles'
  ) loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;

  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'balances'
  ) loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- 3) Recreate NON-RECURSIVE policies (own-row only)
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 4) Backfill missing rows for existing users
insert into public.profiles (id, email, first_name, full_name, role)
select
  u.id,
  u.email,
  coalesce(u.raw_user_meta_data->>'first_name', split_part(coalesce(u.email, ''), '@', 1)),
  coalesce(u.raw_user_meta_data->>'full_name', u.email),
  'user'
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null
on conflict (id) do nothing;

insert into public.balances (user_id, cards_balance, collect_balance)
select p.id, 0, 0
from public.profiles p
left join public.balances b on b.user_id = p.id
where b.user_id is null
on conflict (user_id) do nothing;

-- 5) Promote admin account by email
update public.profiles
set role = 'admin'
where email = 'admin@cank.local';

commit;

-- Verify after running:
-- select id, email, role from public.profiles where email='admin@cank.local';
-- select count(*) as auth_users from auth.users;
-- select count(*) as profiles_rows from public.profiles;
-- select count(*) as balances_rows from public.balances;
