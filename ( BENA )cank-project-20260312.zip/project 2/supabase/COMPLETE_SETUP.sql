-- ============================================
-- CANK BACKEND SETUP - Complete Database Schema
-- ============================================
-- Run this script in your Supabase SQL Editor
-- This sets up ALL tables, policies, and functions
-- ============================================

-- ============================================
-- 1. PROFILES & BALANCES (User Management)
-- ============================================

-- Drop existing tables if any
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();
DROP TABLE IF EXISTS balances CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  first_name text,
  full_name text,
  role text DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create balances table
CREATE TABLE balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  cards_balance numeric DEFAULT 0,
  collect_balance numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_profiles_email ON profiles(email);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_balances_user_id ON balances(user_id);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE balances ENABLE ROW LEVEL SECURITY;

-- Profiles RLS Policies
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Admins can update any profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (true);

-- Balances RLS Policies
CREATE POLICY "Users can read own balances"
  ON balances FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can read all balances"
  ON balances FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can update own balances"
  ON balances FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can insert own balances"
  ON balances FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- ============================================
-- 2. OFFERS SYSTEM
-- ============================================

-- Drop existing offers table if any
DROP TABLE IF EXISTS offers CASCADE;

-- Create offers table
CREATE TABLE offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  type text NOT NULL,
  status text DEFAULT 'available',
  amount numeric DEFAULT 0,
  config jsonb DEFAULT '{}'::jsonb,
  template_id uuid,
  is_template_instance boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  accepted_at timestamptz
);

-- Enable RLS
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for offers
CREATE POLICY "Users can read own offers"
  ON offers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can read all offers"
  ON offers FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can insert own offers"
  ON offers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own offers"
  ON offers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own offers"
  ON offers FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all offers"
  ON offers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ============================================
-- 3. OFFER TEMPLATES SYSTEM
-- ============================================

-- Drop existing templates tables if any
DROP TABLE IF EXISTS offer_assignments CASCADE;
DROP TABLE IF EXISTS offer_templates CASCADE;

-- Create offer_templates table
CREATE TABLE offer_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('cash', 'receivables')),
  amount numeric DEFAULT 0,
  config jsonb DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create offer_assignments table
CREATE TABLE offer_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES offer_templates(id) ON DELETE SET NULL,
  offer_id uuid REFERENCES offers(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  status text DEFAULT 'assigned' CHECK (status IN ('assigned', 'accepted', 'expired', 'cancelled')),
  assigned_at timestamptz DEFAULT now(),
  accepted_at timestamptz,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Add foreign key to offers
ALTER TABLE offers ADD CONSTRAINT fk_offers_template 
  FOREIGN KEY (template_id) REFERENCES offer_templates(id) ON DELETE SET NULL;

-- Indexes for templates
CREATE INDEX idx_offer_templates_type ON offer_templates(type);
CREATE INDEX idx_offer_templates_is_active ON offer_templates(is_active);
CREATE INDEX idx_offer_assignments_template_id ON offer_assignments(template_id);
CREATE INDEX idx_offer_assignments_user_id ON offer_assignments(user_id);

-- Enable RLS
ALTER TABLE offer_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE offer_assignments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for offer_templates
CREATE POLICY "Anyone can read active templates"
  ON offer_templates FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Admins can manage all templates"
  ON offer_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- RLS Policies for offer_assignments
CREATE POLICY "Users can read own assignments"
  ON offer_assignments FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage all assignments"
  ON offer_assignments FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ============================================
-- 4. CONVERSIONS TRACKING
-- ============================================

-- Drop existing conversions table if any
DROP TABLE IF EXISTS conversions CASCADE;

-- Create conversions table
CREATE TABLE conversions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  action text NOT NULL,
  journey_type text,
  offer_id text,
  amount numeric,
  combination text,
  duration text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX idx_conversions_user_id ON conversions(user_id);
CREATE INDEX idx_conversions_created_at ON conversions(created_at DESC);
CREATE INDEX idx_conversions_action ON conversions(action);

-- Enable RLS
ALTER TABLE conversions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can insert conversions"
  ON conversions FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Users can view own conversions"
  ON conversions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid()::text);

CREATE POLICY "Admins can view all conversions"
  ON conversions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ============================================
-- 5. OFFER ANALYTICS (Admin Only)
-- ============================================

-- Drop existing analytics table if any
DROP TABLE IF EXISTS offer_analytics CASCADE;

-- Create offer_analytics table
CREATE TABLE offer_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id uuid NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  template_id uuid REFERENCES offer_templates(id) ON DELETE SET NULL,
  
  -- Core metrics
  views_count int DEFAULT 0,
  clicks_count int DEFAULT 0,
  accepted boolean DEFAULT false,
  accepted_at timestamptz,
  
  -- Timestamps
  first_tracked_at timestamptz DEFAULT now(),
  last_tracked_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(offer_id, user_id)
);

-- Indexes
CREATE INDEX idx_offer_analytics_offer_id ON offer_analytics(offer_id);
CREATE INDEX idx_offer_analytics_user_id ON offer_analytics(user_id);
CREATE INDEX idx_offer_analytics_accepted ON offer_analytics(accepted);

-- Enable RLS
ALTER TABLE offer_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies - ONLY ADMINS CAN ACCESS
CREATE POLICY "Admins only - read all analytics"
  ON offer_analytics FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Block non-admin user access"
  ON offer_analytics FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ============================================
-- 6. FUNCTIONS & TRIGGERS
-- ============================================

-- Auto-create profile and balance when user signs up
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, first_name, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email)
  );

  INSERT INTO balances (user_id, cards_balance, collect_balance)
  VALUES (NEW.id, 0, 0);

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Refresh analytics from conversions data
CREATE OR REPLACE FUNCTION refresh_offer_analytics()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO offer_analytics (
    offer_id,
    user_id,
    template_id,
    views_count,
    clicks_count,
    accepted,
    accepted_at,
    first_tracked_at,
    last_tracked_at,
    updated_at
  )
  SELECT 
    o.id as offer_id,
    o.user_id,
    o.template_id,
    COALESCE(
      (SELECT COUNT(*) FROM conversions 
       WHERE conversions.user_id = o.user_id::text
       AND conversions.metadata->>'offer_id' = o.id::text
       AND conversions.action LIKE '%view%'
      ), 0
    ) as views_count,
    COALESCE(
      (SELECT COUNT(*) FROM conversions 
       WHERE conversions.user_id = o.user_id::text
       AND conversions.metadata->>'offer_id' = o.id::text
       AND conversions.action LIKE '%click%'
      ), 0
    ) as clicks_count,
    (o.status = 'accepted') as accepted,
    o.accepted_at,
    COALESCE(
      (SELECT MIN(created_at) FROM conversions 
       WHERE conversions.user_id = o.user_id::text
       AND conversions.metadata->>'offer_id' = o.id::text
      ), now()
    ) as first_tracked_at,
    COALESCE(
      (SELECT MAX(created_at) FROM conversions 
       WHERE conversions.user_id = o.user_id::text
       AND conversions.metadata->>'offer_id' = o.id::text
      ), now()
    ) as last_tracked_at,
    now() as updated_at
  FROM offers o
  ON CONFLICT (offer_id, user_id) 
  DO UPDATE SET
    views_count = EXCLUDED.views_count,
    clicks_count = EXCLUDED.clicks_count,
    accepted = EXCLUDED.accepted,
    accepted_at = EXCLUDED.accepted_at,
    last_tracked_at = EXCLUDED.last_tracked_at,
    updated_at = now();
END;
$$;

-- Card price calculation (backend-only, never exposed to frontend)
CREATE OR REPLACE FUNCTION calculate_card_price(card_color TEXT, card_quantity INT)
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  price_per_card INT;
BEGIN
  price_per_card := CASE
    WHEN card_color = 'red' THEN 20
    WHEN card_color = 'white' THEN 50
    WHEN card_color = 'sky' THEN 100
    WHEN card_color = 'blue' THEN 150
    WHEN card_color = 'black' THEN 200
    WHEN card_color = 'silver' THEN 250
    WHEN card_color = 'gold' THEN 300
    ELSE 0
  END;

  RETURN price_per_card * card_quantity;
END;
$$;

-- ============================================
-- 7. DEMO DATA - Create Demo User
-- ============================================

-- Insert demo user (if not exists)
-- This creates the hardcoded demo user from your frontend
-- UUID: 00000000-0000-0000-0000-000000000001

-- Note: This won't work if auth.users is managed by Supabase Auth
-- Instead, we'll create a profile directly for the demo user
-- You'll need to create the actual auth user through Supabase Auth UI

-- ============================================
-- SETUP COMPLETE!
-- ============================================
-- Next steps:
-- 1. Create a user account via Supabase Auth
-- 2. Set that user's role to 'admin' in the profiles table
-- 3. Your app will connect and everything will work!
-- ============================================
