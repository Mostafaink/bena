-- LOCALHOST DEMO CONNECTIVITY FIX (safe to re-run)
-- Purpose: make current localhost demo mode actually read/write Supabase.
-- This is DEV-ONLY. For production, run MVP_PRODUCTION_BASELINE.sql instead.

-- --------------------------------------------
-- 1) OFFERS: allow anon + authenticated in demo
-- --------------------------------------------
ALTER TABLE IF EXISTS offers ENABLE ROW LEVEL SECURITY;

-- If this FK exists, demo UUID inserts fail unless user exists in auth.users
ALTER TABLE IF EXISTS offers DROP CONSTRAINT IF EXISTS offers_user_id_fkey;

DROP POLICY IF EXISTS "Users can read own offers" ON offers;
DROP POLICY IF EXISTS "Users can insert own offers" ON offers;
DROP POLICY IF EXISTS "Users can update own offers" ON offers;
DROP POLICY IF EXISTS "Users can delete own offers" ON offers;
DROP POLICY IF EXISTS "Admins can read all offers" ON offers;
DROP POLICY IF EXISTS "Admins can manage all offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to read offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to insert offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to update offers" ON offers;
DROP POLICY IF EXISTS "Allow demo user to delete offers" ON offers;
DROP POLICY IF EXISTS "Demo read offers" ON offers;
DROP POLICY IF EXISTS "Demo insert offers" ON offers;
DROP POLICY IF EXISTS "Demo update offers" ON offers;
DROP POLICY IF EXISTS "Demo delete offers" ON offers;
DROP POLICY IF EXISTS "offers_select_own_or_admin" ON offers;
DROP POLICY IF EXISTS "offers_insert_own_or_admin" ON offers;
DROP POLICY IF EXISTS "offers_update_own_or_admin" ON offers;
DROP POLICY IF EXISTS "offers_delete_admin_only" ON offers;

CREATE POLICY "demo_offers_read"
  ON offers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_offers_insert"
  ON offers FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_offers_update"
  ON offers FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "demo_offers_delete"
  ON offers FOR DELETE
  TO anon, authenticated
  USING (true);

-- --------------------------------------------
-- 2) TEMPLATES + ASSIGNMENTS for Admin UI
-- --------------------------------------------
ALTER TABLE IF EXISTS offer_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Admins can manage all templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow read active templates" ON offer_templates;
DROP POLICY IF EXISTS "Allow manage templates demo" ON offer_templates;
DROP POLICY IF EXISTS "Demo read templates" ON offer_templates;
DROP POLICY IF EXISTS "Demo manage templates" ON offer_templates;
DROP POLICY IF EXISTS "templates_select_authenticated" ON offer_templates;
DROP POLICY IF EXISTS "templates_manage_admin_only" ON offer_templates;

CREATE POLICY "demo_templates_read"
  ON offer_templates FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_templates_manage"
  ON offer_templates FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

ALTER TABLE IF EXISTS offer_assignments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Admins can manage all assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Allow manage assignments demo" ON offer_assignments;
DROP POLICY IF EXISTS "Demo read assignments" ON offer_assignments;
DROP POLICY IF EXISTS "Demo manage assignments" ON offer_assignments;
DROP POLICY IF EXISTS "assignments_select_own_or_admin" ON offer_assignments;
DROP POLICY IF EXISTS "assignments_manage_admin_only" ON offer_assignments;

CREATE POLICY "demo_assignments_read"
  ON offer_assignments FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_assignments_manage"
  ON offer_assignments FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- --------------------------------------------
-- 3) USER FLOWS used by frontend flow state
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS user_flows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL UNIQUE,
  flow_type text NOT NULL DEFAULT 'standard',
  current_modal_step integer DEFAULT 0,
  last_action text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_flows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can read user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can insert user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can update user flows" ON user_flows;
DROP POLICY IF EXISTS "Anyone can delete user flows" ON user_flows;
DROP POLICY IF EXISTS "Demo read flows" ON user_flows;
DROP POLICY IF EXISTS "Demo insert flows" ON user_flows;
DROP POLICY IF EXISTS "Demo update flows" ON user_flows;
DROP POLICY IF EXISTS "Demo delete flows" ON user_flows;
DROP POLICY IF EXISTS "flows_select_own_or_admin" ON user_flows;
DROP POLICY IF EXISTS "flows_insert_own_or_admin" ON user_flows;
DROP POLICY IF EXISTS "flows_update_own_or_admin" ON user_flows;
DROP POLICY IF EXISTS "flows_delete_admin_only" ON user_flows;

CREATE POLICY "demo_flows_read"
  ON user_flows FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_flows_insert"
  ON user_flows FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_flows_update"
  ON user_flows FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "demo_flows_delete"
  ON user_flows FOR DELETE
  TO anon, authenticated
  USING (true);

-- --------------------------------------------
-- 4) CONVERSIONS tracking (append in demo)
-- --------------------------------------------
ALTER TABLE IF EXISTS conversions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can insert conversions" ON conversions;
DROP POLICY IF EXISTS "Users can view own conversions" ON conversions;
DROP POLICY IF EXISTS "Admins can view all conversions" ON conversions;
DROP POLICY IF EXISTS "conversions_insert_own" ON conversions;
DROP POLICY IF EXISTS "conversions_select_own_or_admin" ON conversions;

CREATE POLICY "demo_conversions_insert"
  ON conversions FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_conversions_read"
  ON conversions FOR SELECT
  TO anon, authenticated
  USING (true);

-- --------------------------------------------
-- 5) Ensure demo profile + balance exist
-- --------------------------------------------
INSERT INTO profiles (id, email, first_name, full_name, role, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.local',
  'Demo',
  'Demo User',
  'admin',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE
SET role = 'admin',
    first_name = 'Demo',
    full_name = 'Demo User',
    updated_at = NOW();

INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000,
  500,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE
SET cards_balance = EXCLUDED.cards_balance,
    collect_balance = EXCLUDED.collect_balance,
    updated_at = NOW();

-- quick check
SELECT 'localhost_demo_policies_applied' AS status;
