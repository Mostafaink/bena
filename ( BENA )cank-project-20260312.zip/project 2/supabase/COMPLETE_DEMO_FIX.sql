-- COMPLETE LOCALHOST DEMO FIX (run this in Supabase SQL Editor)
-- This fixes ALL remaining issues

-- 1) Add phone columns to profiles if missing
ALTER TABLE profiles 
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS phone_national text;

-- 2) Make profiles.email nullable for phone-only users
ALTER TABLE profiles 
  ALTER COLUMN email DROP NOT NULL;

-- 3) Ensure profiles has permissive RLS for demo
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "demo_profiles_read" ON profiles;
DROP POLICY IF EXISTS "demo_profiles_manage" ON profiles;

CREATE POLICY "demo_profiles_read"
  ON profiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_profiles_manage"
  ON profiles FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- 4) Fix balances RLS to allow demo inserts
ALTER TABLE balances ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own balance" ON balances;
DROP POLICY IF EXISTS "Users can update own balance" ON balances;
DROP POLICY IF EXISTS "demo_balances_read" ON balances;
DROP POLICY IF EXISTS "demo_balances_manage" ON balances;

CREATE POLICY "demo_balances_read"
  ON balances FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_balances_manage"
  ON balances FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- 5) Insert demo profile
INSERT INTO profiles (id, email, first_name, full_name, role, phone, phone_national, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.local',
  'Demo',
  'Demo User',
  'admin',
  '+201000000000',
  '01000000000',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE
SET role = 'admin',
    first_name = 'Demo',
    full_name = 'Demo User',
    email = 'demo@cank.local',
    phone = '+201000000000',
    phone_national = '01000000000',
    updated_at = NOW();

-- 6) Insert demo balance
INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000.00,
  500.00,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE
SET cards_balance = 1000.00,
    collect_balance = 500.00,
    updated_at = NOW();

-- 7) Verify setup
SELECT 
  'DEMO SETUP COMPLETE' as status,
  (SELECT COUNT(*) FROM profiles WHERE id = '00000000-0000-0000-0000-000000000001') as profile_exists,
  (SELECT COUNT(*) FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000001') as balance_exists,
  (SELECT COUNT(*) FROM offers WHERE user_id = '00000000-0000-0000-0000-000000000001') as offers_count;
