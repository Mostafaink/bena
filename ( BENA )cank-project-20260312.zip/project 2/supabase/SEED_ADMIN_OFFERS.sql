-- SEED_ADMIN_OFFERS.sql
-- Check offers table and seed initial offers for admin

begin;

-- Diagnostic: see what's in offers table
select 'ALL_OFFERS' as info, count(*) as total from public.offers;
select 'OFFERS_BY_USER' as info, user_id, count(*) from public.offers group by user_id;

-- Delete any existing offers for admin to start fresh
delete from public.offers where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;

-- Seed receivables offers (matches original frontend logic)
insert into public.offers (user_id, type, amount, status, config, created_at, updated_at)
values
  ('616d5628-12fe-46c5-a216-92ceb00936bb'::uuid, 'receivables', 500, 'active', 
   '{"enabled_count": 1, "combinations": [{"red": 1, "white": 1, "sky": 1, "blue": 1, "black": 1, "silver": 1, "gold": 1}], "schedules": [{"amount": 100, "dueDate": "2024-12-15", "status": "upcoming"}], "schedule_enabled_count": 1}'::jsonb,
   now(), now()),
  
  ('616d5628-12fe-46c5-a216-92ceb00936bb'::uuid, 'receivables', 1000, 'active',
   '{"enabled_count": 2, "combinations": [{"red": 2, "white": 2, "sky": 2, "blue": 2, "black": 2, "silver": 2, "gold": 2}, {"red": 1, "white": 1, "sky": 1, "blue": 1, "black": 1, "silver": 1, "gold": 1}], "schedules": [{"amount": 200, "dueDate": "2024-12-20", "status": "upcoming"}, {"amount": 200, "dueDate": "2025-01-10", "status": "upcoming"}], "schedule_enabled_count": 2}'::jsonb,
   now(), now()),
  
  ('616d5628-12fe-46c5-a216-92ceb00936bb'::uuid, 'receivables', 1500, 'active',
   '{"enabled_count": 1, "combinations": [{"red": 3, "white": 3, "sky": 3, "blue": 3, "black": 3, "silver": 3, "gold": 3}], "schedules": [{"amount": 300, "dueDate": "2025-01-15", "status": "upcoming"}], "schedule_enabled_count": 1}'::jsonb,
   now(), now());

-- Seed cash offer
insert into public.offers (user_id, type, amount, status, config, created_at, updated_at)
values
  ('616d5628-12fe-46c5-a216-92ceb00936bb'::uuid, 'cash', 2000, 'active',
   '{}'::jsonb, now(), now());

commit;

-- Verification
select 'SEEDED_OFFERS' as result, type, count(*) as count, sum(amount) as total_amount
from public.offers
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
group by type;

select 'TOTAL_FOR_ADMIN' as result, count(*) as offer_count 
from public.offers 
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
