-- Phone-first authentication support for Egypt (+20)
-- Run this once in Supabase SQL Editor

-- 1) Profiles must support phone users (email can be null for phone-only auth)
ALTER TABLE profiles
  ALTER COLUMN email DROP NOT NULL;

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS phone text;

CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_phone_unique
  ON profiles(phone)
  WHERE phone IS NOT NULL;

-- 2) Update signup trigger to handle phone OR email signups safely
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, phone, first_name, full_name, role, created_at, updated_at)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.phone,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'first_name',
      NEW.phone,
      NEW.email,
      'User'
    ),
    'user',
    now(),
    now()
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
  VALUES (NEW.id, 0, 0, now(), now())
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- 3) Backfill profiles for existing auth users if missing
INSERT INTO profiles (id, email, phone, first_name, full_name, role, created_at, updated_at)
SELECT
  u.id,
  u.email,
  u.phone,
  COALESCE(u.raw_user_meta_data->>'first_name', ''),
  COALESCE(
    u.raw_user_meta_data->>'full_name',
    u.raw_user_meta_data->>'first_name',
    u.phone,
    u.email,
    'User'
  ),
  'user',
  now(),
  now()
FROM auth.users u
ON CONFLICT (id) DO NOTHING;

INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
SELECT u.id, 0, 0, now(), now()
FROM auth.users u
ON CONFLICT (user_id) DO NOTHING;

SELECT 'phone_auth_ready' AS status;
