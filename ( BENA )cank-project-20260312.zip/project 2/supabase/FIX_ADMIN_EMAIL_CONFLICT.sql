-- FIX_ADMIN_EMAIL_CONFLICT.sql
-- Resolves duplicate email conflict for admin@cank.local
-- and links admin profile to the real auth user id.
-- Run this in Supabase SQL Editor.

begin;

-- Replace with the auth user id that already exists in Supabase Auth
-- from your error flow.
-- Current known auth user id:
-- 616d5628-12fe-46c5-a216-92ceb00936bb

-- 1) Ensure target auth user id exists in auth.users
-- (If this returns 0 rows, use the correct id from Auth table)
select id, email from auth.users where id = '616d5628-12fe-46c5-a216-92ceb00936bb';

-- 2) Temporarily rename legacy admin profile email if it exists on a different id
update public.profiles
set email = 'legacy+' || id::text || '@cank.local'
where email = 'admin@cank.local'
  and id <> '616d5628-12fe-46c5-a216-92ceb00936bb';

-- 3) Upsert admin profile on the correct auth user id
insert into public.profiles (id, email, first_name, full_name, role)
values (
  '616d5628-12fe-46c5-a216-92ceb00936bb',
  'admin@cank.local',
  'Admin',
  'Admin User',
  'admin'
)
on conflict (id) do update
set email = excluded.email,
    first_name = excluded.first_name,
    full_name = excluded.full_name,
    role = 'admin';

-- 4) Ensure balances row exists for correct admin id
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '616d5628-12fe-46c5-a216-92ceb00936bb',
  10000,
  5000
)
on conflict (user_id) do update
set cards_balance = excluded.cards_balance,
    collect_balance = excluded.collect_balance;

commit;

-- Verify
select id, email, role from public.profiles where email = 'admin@cank.local';
select user_id, cards_balance, collect_balance from public.balances where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb';
