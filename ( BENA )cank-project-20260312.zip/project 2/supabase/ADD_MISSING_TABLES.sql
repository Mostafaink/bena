-- Create/fix demo flow support in public schema (safe to re-run)

CREATE TABLE IF NOT EXISTS public.user_flows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  flow_type text NOT NULL DEFAULT 'standard',
  current_modal_step integer DEFAULT 0,
  last_action text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.user_flows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "demo_flows_read" ON public.user_flows;
DROP POLICY IF EXISTS "demo_flows_insert" ON public.user_flows;
DROP POLICY IF EXISTS "demo_flows_update" ON public.user_flows;
DROP POLICY IF EXISTS "demo_flows_delete" ON public.user_flows;
DROP POLICY IF EXISTS "Anyone can read user flows" ON public.user_flows;
DROP POLICY IF EXISTS "Anyone can insert user flows" ON public.user_flows;
DROP POLICY IF EXISTS "Anyone can update user flows" ON public.user_flows;
DROP POLICY IF EXISTS "Anyone can delete user flows" ON public.user_flows;

CREATE POLICY "demo_flows_read"
  ON public.user_flows FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "demo_flows_insert"
  ON public.user_flows FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "demo_flows_update"
  ON public.user_flows FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "demo_flows_delete"
  ON public.user_flows FOR DELETE
  TO anon, authenticated
  USING (true);

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.user_flows TO anon, authenticated;

-- Important: refresh PostgREST schema cache so /rest/v1/user_flows resolves immediately.
NOTIFY pgrst, 'reload schema';

-- Only assign missing offers to demo user (UUID-safe)
UPDATE public.offers
SET user_id = '00000000-0000-0000-0000-000000000001'::uuid
WHERE user_id IS NULL;

INSERT INTO public.user_flows (user_id, flow_type, current_modal_step)
VALUES ('00000000-0000-0000-0000-000000000001'::uuid, 'standard', 0)
ON CONFLICT (user_id) DO UPDATE
SET flow_type = EXCLUDED.flow_type,
    updated_at = now();

SELECT
  'setup_complete' AS status,
  (SELECT COUNT(*) FROM public.user_flows) AS total_flows,
  (SELECT COUNT(*) FROM public.offers WHERE user_id = '00000000-0000-0000-0000-000000000001'::uuid) AS demo_offers,
  (SELECT COUNT(*) FROM public.offers WHERE status = 'available') AS available_offers;
