-- CREATE_ADMIN_USER_IN_AUTH.sql
-- Run this ONLY if admin@cank.local doesn't exist in Supabase Auth → Users

-- First, create the user in auth.users (you can also do this via the Supabase dashboard)
-- Note: You CANNOT directly insert into auth.users via SQL for security reasons
-- Instead, use the Supabase Dashboard:
-- 1. Go to Authentication → Users
-- 2. Click "Add User"
-- 3. Email: admin@cank.local
-- 4. Password: admin123
-- 5. Auto Confirm User: YES

-- After creating the user in the dashboard, run THIS part to set up profile:

-- Create profile entry for admin user
-- Replace USER_ID_FROM_DASHBOARD with the actual UUID you see after creating the user  
insert into public.profiles (id, email, role, first_name, full_name)
values (
  'USER_ID_FROM_DASHBOARD'::uuid,  -- Replace this!
  'admin@cank.local',
  'admin',
  'Admin',
  'Admin User'
)
on conflict (id) do update
set role = 'admin', email = 'admin@cank.local', first_name = 'Admin', full_name = 'Admin User';

-- Create balance entry for admin user
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  'USER_ID_FROM_DASHBOARD'::uuid,  -- Replace this!
  10000,
  5000
)
on conflict (user_id) do update
set cards_balance = 10000, collect_balance = 5000;
