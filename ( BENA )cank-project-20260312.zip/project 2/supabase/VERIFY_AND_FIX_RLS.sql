-- Check RLS status and disable it
SELECT tablename, rowsecurity FROM pg_tables 
WHERE schemaname = 'public' AND tablename IN ('profiles', 'balances', 'offers');

-- Force disable RLS
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.balances DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers DISABLE ROW LEVEL SECURITY;

-- Insert admin profile for the auth user that was just created
INSERT INTO public.profiles (id, email, first_name, full_name, role)
VALUES (
  '616d5628-12fe-46c5-a216-92ceb00936bb',
  'admin@cank.local',
  'Admin',
  'Admin User',
  'admin'
)
ON CONFLICT (id) DO UPDATE
SET role = 'admin';

-- Insert admin balance
INSERT INTO public.balances (user_id, cards_balance, collect_balance)
VALUES (
  '616d5628-12fe-46c5-a216-92ceb00936bb',
  10000,
  5000
)
ON CONFLICT (user_id) DO UPDATE
SET cards_balance = 10000, collect_balance = 5000;

-- Verify
SELECT id, email, role FROM public.profiles WHERE email = 'admin@cank.local';
SELECT user_id, cards_balance FROM public.balances WHERE user_id = '616d5628-12fe-46c5-a216-92ceb00936bb';
