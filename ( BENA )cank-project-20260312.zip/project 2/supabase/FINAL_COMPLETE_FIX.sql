-- FINAL_COMPLETE_FIX.sql
-- ONE script to fix all remaining issues
-- Run this ONCE in Supabase SQL Editor

begin;

-- ========================================
-- 1. FIX BALANCE RECURSION
-- ========================================

-- Check current policies causing recursion
select 'BEFORE_FIX' as stage, tablename, policyname 
from pg_policies 
where schemaname = 'public' and tablename in ('profiles', 'balances')
order by tablename, policyname;

-- Drop ALL policies on profiles (some may be recursive)
do $$
declare
  pol record;
begin
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'profiles'
  ) loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;
end $$;

-- Drop ALL policies on balances
do $$
declare
  pol record;
begin
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'balances'
  ) loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- Recreate profiles policies (non-recursive, simple auth.uid() check)
alter table public.profiles enable row level security;

create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- Recreate balances policies (non-recursive, simple auth.uid() check)
alter table public.balances enable row level security;

create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- ========================================
-- 2. ADD OFFERS TABLE RLS POLICIES
-- ========================================

alter table public.offers enable row level security;

-- Drop existing policies
do $$
declare
  pol record;
begin
  for pol in (
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'offers'
  ) loop
    execute format('drop policy if exists %I on public.offers', pol.policyname);
  end loop;
end $$;

-- Create clean policies for offers
create policy offers_select_own
  on public.offers
  for select
  to authenticated
  using (user_id = auth.uid());

create policy offers_insert_own
  on public.offers
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy offers_update_own
  on public.offers
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy offers_delete_own
  on public.offers
  for delete
  to authenticated
  using (user_id = auth.uid());

commit;

-- ========================================
-- VERIFICATION
-- ========================================

select 'AFTER_FIX' as stage, tablename, policyname 
from pg_policies 
where schemaname = 'public' and tablename in ('profiles', 'balances', 'offers')
order by tablename, policyname;

-- Show current admin data
select 'ADMIN_PROFILE' as info, id, email, role 
from public.profiles 
where id = '616d5628-12fe-46c5-a216-92ceb00936bb';

select 'ADMIN_BALANCE' as info, user_id, cards_balance, collect_balance 
from public.balances 
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb';

select 'OFFERS_SUMMARY' as info, 
  status, 
  type, 
  count(*) as count,
  sum(amount) as total
from public.offers 
where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'
group by status, type
order by status, type;

-- Success message
select 'SUCCESS' as result, 
  'All policies fixed. Balance updates should now work.' as message,
  'Test by accepting an offer and checking if balance decreases.' as next_step;
