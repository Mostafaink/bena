-- UNBLOCK_ADMIN_NOW.sql
-- Run this once in Supabase SQL Editor.
-- Goal: remove recursive RLS, restore auth trigger, create is_admin RPC, and link admin role.

begin;

-- 1) Disable RLS during repair to avoid policy recursion while fixing
alter table public.profiles disable row level security;
alter table public.balances disable row level security;

-- 2) Drop all existing policies cleanly
DO $$
DECLARE pol RECORD;
BEGIN
  FOR pol IN (
    SELECT policyname FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'profiles'
  ) LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', pol.policyname);
  END LOOP;

  FOR pol IN (
    SELECT policyname FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'balances'
  ) LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.balances', pol.policyname);
  END LOOP;
END $$;

-- 3) Conflict-safe trigger for new auth users
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Move conflicting email if it belongs to another id
  update public.profiles
  set email = 'legacy+' || id::text || '@cank.local'
  where email = new.email
    and id <> new.id;

  insert into public.profiles (id, email, first_name, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'first_name', split_part(coalesce(new.email, ''), '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    'user'
  )
  on conflict (id) do update
  set email = excluded.email,
      first_name = excluded.first_name,
      full_name = excluded.full_name;

  insert into public.balances (user_id, cards_balance, collect_balance)
  values (new.id, 0, 0)
  on conflict (user_id) do nothing;

  return new;
exception when others then
  raise log 'handle_new_user failed: %', sqlerrm;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- 4) Backend admin RPC (frontend now uses this)
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- 5) Ensure admin email row is attached to the real auth user id
-- (use current auth user by email)
update public.profiles
set email = 'legacy+' || id::text || '@cank.local'
where email = 'admin@cank.local'
  and id <> (select id from auth.users where email = 'admin@cank.local' limit 1);

insert into public.profiles (id, email, first_name, full_name, role)
select
  u.id,
  u.email,
  'Admin',
  'Admin User',
  'admin'
from auth.users u
where u.email = 'admin@cank.local'
on conflict (id) do update
set email = excluded.email,
    first_name = excluded.first_name,
    full_name = excluded.full_name,
    role = 'admin';

insert into public.balances (user_id, cards_balance, collect_balance)
select u.id, 10000, 5000
from auth.users u
where u.email = 'admin@cank.local'
on conflict (user_id) do update
set cards_balance = excluded.cards_balance,
    collect_balance = excluded.collect_balance;

-- 6) Re-enable RLS with non-recursive own-row policies
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

create policy profiles_select_own on public.profiles
  for select to authenticated using (id = auth.uid());

create policy profiles_insert_own on public.profiles
  for insert to authenticated with check (id = auth.uid());

create policy profiles_update_own on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy balances_select_own on public.balances
  for select to authenticated using (user_id = auth.uid());

create policy balances_insert_own on public.balances
  for insert to authenticated with check (user_id = auth.uid());

create policy balances_update_own on public.balances
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

commit;

-- Verify after run:
-- select id, email, role from public.profiles where email='admin@cank.local';
-- select public.is_admin();
