-- FIX_RLS_AND_ADMIN.sql
-- This fixes RLS policies AND creates backend-controlled admin access
-- Run this ONCE in Supabase SQL Editor

begin;

-- Step 1: Temporarily disable RLS to fix policies and insert admin
alter table public.profiles disable row level security;
alter table public.balances disable row level security;

-- Step 2: Drop ALL existing policies to start clean
do $$
declare
  pol record;
begin
  for pol in (select policyname from pg_policies where schemaname = 'public' and tablename = 'profiles') loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;
  for pol in (select policyname from pg_policies where schemaname = 'public' and tablename = 'balances') loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- Step 3: Create WORKING RLS policies
-- Profiles: SELECT (users see own, admins see all), INSERT (anyone during signup), UPDATE (users own, admins all)
create policy "profile_select_own"
  on public.profiles for select
  using (auth.uid() = id OR EXISTS (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

create policy "profile_insert_signup"
  on public.profiles for insert
  with check (true);  -- Anyone can insert during signup

create policy "profile_update_own"
  on public.profiles for update
  using (auth.uid() = id OR EXISTS (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- Balances: SELECT (users see own, admins see all), INSERT (anyone during signup), UPDATE (users own, admins all)
create policy "balance_select_own"
  on public.balances for select
  using (user_id = auth.uid() OR EXISTS (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

create policy "balance_insert_signup"
  on public.balances for insert
  with check (true);  -- Anyone can insert during signup

create policy "balance_update_own"
  on public.balances for update
  using (user_id = auth.uid() OR EXISTS (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- Step 4: Insert admin user profile
insert into public.profiles (id, email, first_name, full_name, role)
values (
  '00000000-0000-0000-0000-000000000001',
  'admin@cank.local',
  'Admin',
  'Admin User',
  'admin'
)
on conflict (id) do update
set role = 'admin';

-- Step 5: Insert admin balance
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '00000000-0000-0000-0000-000000000001',
  10000,
  5000
)
on conflict (user_id) do nothing;

-- Step 6: Re-enable RLS with new policies active
alter table public.profiles enable row level security;
alter table public.balances enable row level security;

commit;

-- SUCCESS! Now:
-- 1. Admin profile exists: admin@cank.local (UUID: 00000000-0000-0000-0000-000000000001)
-- 2. Admin panel will show ONLY when profiles.role = 'admin'
-- 3. Signup will work (INSERT policies allow profile/balance creation)
-- 
-- NEXT: Create matching Supabase Auth user at http://localhost:5175/auth/signup
-- Then manually update that user's profile.role to 'admin' if needed
