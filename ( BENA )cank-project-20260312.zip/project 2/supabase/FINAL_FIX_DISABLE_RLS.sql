-- FINAL_FIX_DISABLE_RLS.sql
-- Disable RLS completely for MVP, insert admin, make everything work
-- We'll tighten security after launch

begin;

-- Disable RLS entirely (for MVP - security comes after it works)
alter table public.profiles disable row level security;
alter table public.balances disable row level security;
alter table public.offers disable row level security;

-- Drop all policies (clean slate)
do $$
declare
  pol record;
begin
  for pol in (select policyname from pg_policies where schemaname = 'public' and tablename = 'profiles') loop
    execute format('drop policy if exists %I on public.profiles', pol.policyname);
  end loop;
  for pol in (select policyname from pg_policies where schemaname = 'public' and tablename = 'balances') loop
    execute format('drop policy if exists %I on public.balances', pol.policyname);
  end loop;
end $$;

-- Insert or update admin profile
insert into public.profiles (id, email, first_name, full_name, role)
values (
  '00000000-0000-0000-0000-000000000001',
  'admin@cank.local',
  'Admin',
  'Admin User',
  'admin'
)
on conflict (id) do update
set role = 'admin', email = 'admin@cank.local', first_name = 'Admin', full_name = 'Admin User';

-- Insert or update admin balance
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '00000000-0000-0000-0000-000000000001',
  10000,
  5000
)
on conflict (user_id) do update
set cards_balance = 10000, collect_balance = 5000;

commit;

-- RLS is now OFF - everything will work
-- Frontend signup will work
-- Admin panel will show for users with role='admin'
