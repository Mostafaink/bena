-- FIX_MVP_SCHEMA_TYPES.sql
-- Purpose:
-- 1) Normalize conversions.user_id from text -> uuid
-- 2) Add missing offers.updated_at used by admin/diagnostics queries
-- 3) Add helpful indexes
--
-- Run this in Supabase SQL Editor.

begin;

-- 1) Keep only rows with valid UUID user_id before type conversion.
--    Invalid rows are copied to a backup table so no data is lost.
create table if not exists conversions_invalid_user_id_backup as
select * from conversions where false;

insert into conversions_invalid_user_id_backup
select *
from conversions
where user_id is not null
  and user_id !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';

delete from conversions
where user_id is not null
  and user_id !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';

-- 2) Convert conversions.user_id text -> uuid.
alter table conversions
  alter column user_id type uuid using nullif(user_id, '')::uuid;

-- 3) Add FK for data integrity (safe, only if missing).
do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'conversions_user_id_fkey'
  ) then
    alter table conversions
      add constraint conversions_user_id_fkey
      foreign key (user_id) references profiles(id)
      on delete set null;
  end if;
end $$;

-- 4) Add missing offers.updated_at if absent.
alter table offers
  add column if not exists updated_at timestamptz default now();

update offers
set updated_at = coalesce(updated_at, created_at, now())
where updated_at is null;

-- 5) Useful indexes for app queries.
create index if not exists idx_offers_user_status on offers(user_id, status);
create index if not exists idx_conversions_user_created on conversions(user_id, created_at desc);

commit;

-- Verification
select 'offers.user_id' as col, data_type
from information_schema.columns
where table_schema='public' and table_name='offers' and column_name='user_id'
union all
select 'conversions.user_id', data_type
from information_schema.columns
where table_schema='public' and table_name='conversions' and column_name='user_id'
union all
select 'profiles.id', data_type
from information_schema.columns
where table_schema='public' and table_name='profiles' and column_name='id';

select count(*) as offers_for_demo
from offers
where user_id = '00000000-0000-0000-0000-000000000001'::uuid;

select count(*) as conversions_for_demo
from conversions
where user_id = '00000000-0000-0000-0000-000000000001'::uuid;
