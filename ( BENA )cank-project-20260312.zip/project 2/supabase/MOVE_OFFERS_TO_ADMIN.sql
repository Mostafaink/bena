-- MOVE_OFFERS_TO_ADMIN.sql
-- Diagnostic + fix for offers stuck on demo user

begin;

-- Show current offers distribution
select 'BEFORE' as stage, user_id, count(*) as offer_count
from public.offers
group by user_id
order by count(*) desc;

-- Move all demo user offers to admin
update public.offers
set user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
where user_id = '00000000-0000-0000-0000-000000000001'::uuid;

-- Move any offers from stale admin profiles
update public.offers
set user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
where user_id in (
  select id from public.profiles 
  where email like 'stale_%@deleted.local'
);

-- Show after state
select 'AFTER' as stage, user_id, count(*) as offer_count
from public.offers
group by user_id
order by count(*) desc;

commit;

-- Final verification
select count(*) as admin_offers from public.offers where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
