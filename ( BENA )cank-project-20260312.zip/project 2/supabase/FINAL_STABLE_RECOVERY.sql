-- FINAL_STABLE_RECOVERY.sql
-- Uses known working auth user ID from live sign-in test.
-- No dependency on auth.users reads.

begin;

-- 1) Remove potentially recursive policies
DO $$
DECLARE
  pol record;
BEGIN
  FOR pol IN (
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'profiles'
  ) LOOP
    EXECUTE format('drop policy if exists %I on public.profiles', pol.policyname);
  END LOOP;

  FOR pol IN (
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'balances'
  ) LOOP
    EXECUTE format('drop policy if exists %I on public.balances', pol.policyname);
  END LOOP;
END $$;

alter table public.profiles enable row level security;
alter table public.balances enable row level security;

create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using (id = auth.uid());

create policy profiles_insert_own
  on public.profiles
  for insert
  to authenticated
  with check (id = auth.uid());

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

create policy balances_select_own
  on public.balances
  for select
  to authenticated
  using (user_id = auth.uid());

create policy balances_insert_own
  on public.balances
  for insert
  to authenticated
  with check (user_id = auth.uid());

create policy balances_update_own
  on public.balances
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 2) Canonical admin user id from live auth sign-in
-- id = 616d5628-12fe-46c5-a216-92ceb00936bb

-- Step 1: Neutralize duplicate emails to avoid unique constraint collision
update public.profiles
set email = 'stale_' || id::text || '@deleted.local'
where lower(email) = 'admin@cank.local'
  and id <> '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;

-- Step 2: Create/update canonical profile (now email is free)
insert into public.profiles (id, email, role, first_name, full_name)
values (
  '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid,
  'admin@cank.local',
  'admin',
  'Admin',
  'Admin User'
)
on conflict (id) do update
set email = 'admin@cank.local',
    role = 'admin',
    first_name = 'Admin',
    full_name = 'Admin User';

-- Step 3: Repoint stale offers/balances to canonical profile
update public.offers
set user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
where user_id in (
  select id
  from public.profiles
  where email like 'stale_%@deleted.local'
);

update public.balances
set user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid
where user_id in (
  select id
  from public.profiles
  where email like 'stale_%@deleted.local'
);

-- Step 4: Delete neutralized stale profiles
delete from public.profiles
where email like 'stale_%@deleted.local';

-- Step 5: Upsert canonical balance
insert into public.balances (user_id, cards_balance, collect_balance)
values (
  '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid,
  10000,
  5000
)
on conflict (user_id) do update
set cards_balance = excluded.cards_balance,
    collect_balance = excluded.collect_balance;

commit;

-- Verification
select id, email, role from public.profiles where id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
select user_id, cards_balance, collect_balance from public.balances where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
select count(*) as offers_count from public.offers where user_id = '616d5628-12fe-46c5-a216-92ceb00936bb'::uuid;
