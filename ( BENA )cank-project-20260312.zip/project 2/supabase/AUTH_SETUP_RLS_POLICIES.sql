-- AUTH_SETUP_RLS_POLICIES.sql
-- Purpose: Ensure signup can create profiles and balances under RLS
-- Safe to run multiple times.

begin;

drop policy if exists "Anyone can create a profile during signup" on public.profiles;
drop policy if exists "Anyone can create a balance during signup" on public.balances;

create policy "Anyone can create a profile during signup"
  on public.profiles
  for insert
  with check (true);

create policy "Anyone can create a balance during signup"
  on public.balances
  for insert
  with check (true);

commit;

-- After this succeeds:
-- 1) Sign up in app
-- 2) Promote your user to admin:
--    update public.profiles set role = 'admin' where id = 'YOUR_USER_UUID';
