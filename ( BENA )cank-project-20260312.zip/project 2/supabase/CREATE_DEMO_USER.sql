-- ============================================
-- CREATE DEMO USER FOR TESTING
-- ============================================
-- Two options below - use Option 1 for quick testing
-- ============================================

-- ============================================
-- OPTION 1: Drop foreign key constraint temporarily for demo
-- ============================================

-- Temporarily remove the foreign key constraint
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- Create demo profile without needing auth.users
INSERT INTO profiles (id, email, first_name, full_name, role, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'demo@cank.com',
  'Demo',
  'Demo Admin',
  'admin',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE 
SET role = 'admin', first_name = 'Demo', full_name = 'Demo Admin';

-- Create demo balance
INSERT INTO balances (user_id, cards_balance, collect_balance, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  1000,
  500,
  NOW(),
  NOW()
)
ON CONFLICT (user_id) DO UPDATE
SET cards_balance = 1000, collect_balance = 500;

-- Verify it worked
SELECT * FROM profiles WHERE id = '00000000-0000-0000-0000-000000000001';
SELECT * FROM balances WHERE user_id = '00000000-0000-0000-0000-000000000001';

-- ============================================
-- OPTION 2: Create real auth user (for production)
-- ============================================
-- If you want proper authentication later:
-- 1. Go to Authentication > Users in Supabase Dashboard
-- 2. Click "Add user" or "Invite user"
-- 3. Email: demo@cank.com, Password: Demo123!
-- 4. Check "Auto Confirm User"
-- 5. Copy the user ID created
-- 6. Run: UPDATE profiles SET role = 'admin' WHERE id = 'YOUR-USER-ID';
-- ============================================

-- ============================================
-- SUCCESS!
-- ============================================
-- Now you can:
-- 1. Open your app at http://localhost:5173
-- 2. Press Ctrl+Shift+A to open Admin Panel
-- 3. Create offers and test everything!
-- ============================================

