-- ONE_SHOT_RECOVERY.sql
-- Run this once in Supabase SQL Editor.
-- Purpose:
-- 1) Fix auth signup failures ("Database error creating new user")
-- 2) Ensure profiles + balances are auto-created safely
-- 3) Restore backend-controlled admin panel via profiles.role='admin'

begin;

-- 1) Recreate a conflict-safe trigger function for new auth users
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- If same email already exists on a different profile id, move it aside.
  update public.profiles
  set email = 'legacy+' || id::text || '@cank.local'
  where email = new.email
    and id <> new.id;

  -- Upsert profile for the new auth user.
  insert into public.profiles (id, email, first_name, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'first_name', split_part(coalesce(new.email, ''), '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    'user'
  )
  on conflict (id) do update
  set email = excluded.email,
      first_name = excluded.first_name,
      full_name = excluded.full_name;

  -- Ensure balances row exists.
  insert into public.balances (user_id, cards_balance, collect_balance)
  values (new.id, 0, 0)
  on conflict (user_id) do nothing;

  return new;
exception
  when others then
    -- Never block auth user creation because of profile/balance edge cases.
    raise log 'handle_new_user failed: %', sqlerrm;
    return new;
end;
$$;

-- Recreate trigger
 drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- 2) Backfill missing profiles for existing auth users
insert into public.profiles (id, email, first_name, full_name, role)
select
  u.id,
  u.email,
  coalesce(u.raw_user_meta_data->>'first_name', split_part(coalesce(u.email, ''), '@', 1)),
  coalesce(u.raw_user_meta_data->>'full_name', u.email),
  'user'
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null
on conflict (id) do nothing;

-- 3) Backfill missing balances
insert into public.balances (user_id, cards_balance, collect_balance)
select p.id, 0, 0
from public.profiles p
left join public.balances b on b.user_id = p.id
where b.user_id is null
on conflict (user_id) do nothing;

-- 4) Promote admin user by email (if it exists)
update public.profiles
set role = 'admin'
where email = 'admin@cank.local';

commit;

-- Verify (run after commit):
-- select id, email, role from public.profiles where email='admin@cank.local';
-- select count(*) from auth.users;
-- select count(*) from public.profiles;
-- select count(*) from public.balances;
