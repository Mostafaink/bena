import { supabase } from './supabase';

/**
 * Admin-only analytics functions
 * These functions are only accessible to users with 'admin' role
 */

// Refresh analytics from conversions data
export async function refreshAnalytics(): Promise<boolean> {
  try {
    const { error } = await supabase.rpc('refresh_offer_analytics');
    
    if (error) {
      console.error('Error refreshing analytics:', error);
      return false;
    }
    
    return true;
  } catch (err) {
    console.error('Error refreshing analytics:', err);
    return false;
  }
}

// Get all offer analytics (admin only)
export async function getAllOfferAnalytics() {
  try {
    const { data, error } = await supabase
      .from('offer_analytics')
      .select('*')
      .order('updated_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching analytics:', error);
      return [];
    }
    
    return data || [];
  } catch (err) {
    console.error('Error fetching analytics:', err);
    return [];
  }
}

// Get analytics for a specific offer
export async function getOfferAnalytics(offerId: string) {
  try {
    const { data, error } = await supabase
      .from('offer_analytics')
      .select('*')
      .eq('offer_id', offerId);
    
    if (error) {
      console.error('Error fetching offer analytics:', error);
      return [];
    }
    
    return data || [];
  } catch (err) {
    console.error('Error fetching offer analytics:', err);
    return [];
  }
}

// Get aggregated statistics across all offers
export async function getAggregatedStats() {
  try {
    const analytics = await getAllOfferAnalytics();
    
    const totalViews = analytics.reduce((sum, a) => sum + (a.views_count || 0), 0);
    const totalClicks = analytics.reduce((sum, a) => sum + (a.clicks_count || 0), 0);
    const totalAccepts = analytics.filter(a => a.accepted).length;
    const acceptRate = totalViews > 0 ? (totalAccepts / totalViews * 100).toFixed(2) : '0.00';
    
    return {
      totalOffers: analytics.length,
      totalViews,
      totalClicks,
      totalAccepts,
      acceptRate: `${acceptRate}%`,
      clickThroughRate: totalViews > 0 ? `${(totalClicks / totalViews * 100).toFixed(2)}%` : '0.00%',
    };
  } catch (err) {
    console.error('Error calculating aggregated stats:', err);
    return null;
  }
}

// Check if current user is admin
export async function checkIsAdmin(userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', userId)
      .single();
    
    if (error || !data) {
      return false;
    }
    
    return data.role === 'admin';
  } catch (err) {
    console.error('Error checking admin status:', err);
    return false;
  }
}
