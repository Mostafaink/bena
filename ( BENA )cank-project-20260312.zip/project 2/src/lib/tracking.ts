import { supabase } from './supabase';

export async function trackConversion(
  userId: string,
  action: string,
  metadata?: Record<string, any>
) {
  try {
    console.log(`[TRACKING] Recording: ${action} for user ${userId}`, metadata);
    
    const { data, error } = await supabase
      .from('conversions')
      .insert({
        user_id: userId,
        action,
        metadata: metadata || {}
      })
      .select();

    if (error) {
      console.error(`[TRACKING ERROR] Failed to track ${action}:`, error);
      return false;
    } else {
      console.log(`[TRACKING SUCCESS] ${action} recorded, data:`, data);
      return true;
    }
  } catch (err) {
    console.error(`[TRACKING EXCEPTION] ${action}:`, err);
    return false;
  }
}

export async function trackModalClick(
  userId: string,
  modalName: string,
  clickAction: 'accept' | 'recheck',
  modalStep?: number,
  metadata?: Record<string, any>
) {
  try {
    const action = `${modalName}_${clickAction}`;
    console.log(`[TRACKING] Modal click: ${action} for user ${userId}`);
    
    const { data, error } = await supabase
      .from('conversions')
      .insert({
        user_id: userId,
        action,
        metadata: {
          modal_name: modalName,
          click_action: clickAction,
          modal_step: modalStep,
          ...metadata,
        }
      })
      .select();

    if (error) {
      console.error(`[TRACKING ERROR] Failed to track ${action}:`, error);
      return false;
    } else {
      console.log(`[TRACKING SUCCESS] ${action} recorded, data:`, data);
      return true;
    }
  } catch (err) {
    console.error(`[TRACKING EXCEPTION] Modal click error:`, err);
    return false;
  }
}

// Offer-specific tracking for analytics aggregation
export async function trackOfferView(
  userId: string,
  offerId: string,
  offerType: string,
  metadata?: Record<string, any>
) {
  return trackConversion(userId, 'offer_view', {
    offer_id: offerId,
    offer_type: offerType,
    ...metadata,
  });
}

export async function trackOfferClick(
  userId: string,
  offerId: string,
  offerType: string,
  metadata?: Record<string, any>
) {
  return trackConversion(userId, 'offer_click', {
    offer_id: offerId,
    offer_type: offerType,
    ...metadata,
  });
}

export async function trackOfferAccept(
  userId: string,
  offerId: string,
  offerType: string,
  offerAmount: number,
  metadata?: Record<string, any>
) {
  return trackConversion(userId, 'offer_accept', {
    offer_id: offerId,
    offer_type: offerType,
    offer_amount: offerAmount,
    ...metadata,
  });
}
