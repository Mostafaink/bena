import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
	throw new Error(
		'Missing Supabase environment variables. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in project 2/.env'
	);
}

if (!supabaseUrl.startsWith('https://')) {
	throw new Error('Invalid VITE_SUPABASE_URL. It should look like https://<project-ref>.supabase.co');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
