import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { trackConversion } from '../lib/tracking';

interface AuthGateProps {
  onSignedIn: (userId: string) => void;
}

export default function AuthGate({ onSignedIn }: AuthGateProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  async function handleAuth() {
    setError('');
    setLoading(true);

    try {
      if (mode === 'signup') {
        // Sign up
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              first_name: email.split('@')[0],
              full_name: email.split('@')[0],
            }
          }
        });

        if (authError) {
          const msg = (authError.message || '').toLowerCase();
          if (msg.includes('rate limit')) {
            setError('Too many signup attempts right now. Please wait a few minutes and try again.');
          } else {
            setError(authError.message);
          }
          setLoading(false);
          return;
        }

        if (authData.user?.id) {
          // Create profile for new user
          const { error: profileError } = await supabase
            .from('profiles')
            .insert({
              id: authData.user.id,
              email: email,
              first_name: email.split('@')[0],
              full_name: email.split('@')[0],
            });

          if (profileError && !profileError.message.includes('duplicate')) {
            console.error('Profile creation error:', profileError);
          }

          await trackConversion(authData.user.id, 'signup', {
            method: 'email_password',
            email_domain: email.split('@')[1] || 'unknown',
          });

          setError('Account created! Please log in.');
          setMode('login');
          setPassword('');
        }
      } else {
        // Log in
        const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (authError) {
          setError(authError.message);
          setLoading(false);
          return;
        }

        if (authData.user?.id) {
          // Ensure profile exists
          const { data: existingProfile } = await supabase
            .from('profiles')
            .select('id')
            .eq('id', authData.user.id)
            .maybeSingle();

          if (!existingProfile) {
            await supabase
              .from('profiles')
              .insert({
                id: authData.user.id,
                email: authData.user.email,
                first_name: authData.user.user_metadata?.first_name || email.split('@')[0],
                full_name: authData.user.user_metadata?.full_name || email.split('@')[0],
              });
          }

          await trackConversion(authData.user.id, 'login', {
            method: 'email_password',
          });

          onSignedIn(authData.user.id);
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
        <h1 className="text-3xl font-extrabold text-center mb-2">Cank</h1>
        <p className="text-center text-neutral-600 mb-6">Financial offers platform</p>

        <div className="space-y-4">
          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
            disabled={loading}
          />
          
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
            disabled={loading}
          />

          {error && (
            <div className="p-3 bg-red-50 border border-red-300 rounded-xl text-red-700 text-sm">
              {error}
            </div>
          )}

          <button
            onClick={handleAuth}
            disabled={loading || !email || !password}
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>

          <button
            onClick={() => {
              setMode(mode === 'login' ? 'signup' : 'login');
              setError('');
              setPassword('');
            }}
            disabled={loading}
            className="w-full py-3 text-blue-600 font-semibold hover:text-blue-700 disabled:opacity-50"
          >
            {mode === 'login' ? 'Need an account? Sign up' : 'Already have an account? Sign in'}
          </button>
        </div>

        <div className="mt-6 pt-6 border-t border-neutral-200 text-xs text-neutral-600">
          <p className="mb-2">Demo credentials:</p>
          <p>Email: demo@cank.local</p>
          <p>Password: demo123456</p>
        </div>
      </div>
    </div>
  );
}
